// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.


package projet_data.projet_data_3_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: projet_data_3 Purpose: Database<br>
 * Description:  <br>
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status 
 */
public class projet_data_3 implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(connexion_projet_File != null){
				
					this.setProperty("connexion_projet_File", connexion_projet_File.toString());
				
			}
			
			if(context_alimconfiance_Encoding != null){
				
					this.setProperty("context_alimconfiance_Encoding", context_alimconfiance_Encoding.toString());
				
			}
			
			if(context_alimconfiance_FieldSeparator != null){
				
					this.setProperty("context_alimconfiance_FieldSeparator", context_alimconfiance_FieldSeparator.toString());
				
			}
			
			if(context_alimconfiance_File != null){
				
					this.setProperty("context_alimconfiance_File", context_alimconfiance_File.toString());
				
			}
			
			if(context_alimconfiance_Header != null){
				
					this.setProperty("context_alimconfiance_Header", context_alimconfiance_Header.toString());
				
			}
			
			if(context_alimconfiance_RowSeparator != null){
				
					this.setProperty("context_alimconfiance_RowSeparator", context_alimconfiance_RowSeparator.toString());
				
			}
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

		public String connexion_projet_File;
		public String getConnexion_projet_File(){
			return this.connexion_projet_File;
		}
		
public String context_alimconfiance_Encoding;
public String getContext_alimconfiance_Encoding(){
	return this.context_alimconfiance_Encoding;
}
public String context_alimconfiance_FieldSeparator;
public String getContext_alimconfiance_FieldSeparator(){
	return this.context_alimconfiance_FieldSeparator;
}
		public String context_alimconfiance_File;
		public String getContext_alimconfiance_File(){
			return this.context_alimconfiance_File;
		}
		
public Integer context_alimconfiance_Header;
public Integer getContext_alimconfiance_Header(){
	return this.context_alimconfiance_Header;
}
public String context_alimconfiance_RowSeparator;
public String getContext_alimconfiance_RowSeparator(){
	return this.context_alimconfiance_RowSeparator;
}
	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "projet_data_3";
	private final String projectName = "PROJET_DATA";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				projet_data_3.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(projet_data_3.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBCommit_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBCommit_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBCommit_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	





public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";

	
		int tos_count_tDBConnection_1 = 0;
		


	
		String url_tDBConnection_1 = "jdbc:sqlite:" + "/" + context.connexion_projet_File; 
	String dbUser_tDBConnection_1 = null;
	
	
		String dbPwd_tDBConnection_1 = null;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
					String driverClass_tDBConnection_1 = "org.sqlite.JDBC";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
		conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1);

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			conn_tDBConnection_1.setAutoCommit(false);
	}


 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tFileInputDelimited_1Process(globalMap);



/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	


public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_PROJET_DATA_projet_data_3 = new byte[0];
    static byte[] commonByteArray_PROJET_DATA_projet_data_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String Numero_inspection;

				public String getNumero_inspection () {
					return this.Numero_inspection;
				}
				
			    public String evaluation_sanitaire;

				public String getEvaluation_sanitaire () {
					return this.evaluation_sanitaire;
				}
				
			    public java.util.Date Date_inspection;

				public java.util.Date getDate_inspection () {
					return this.Date_inspection;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.Numero_inspection == null) ? 0 : this.Numero_inspection.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row7Struct other = (row7Struct) obj;
		
						if (this.Numero_inspection == null) {
							if (other.Numero_inspection != null)
								return false;
						
						} else if (!this.Numero_inspection.equals(other.Numero_inspection))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row7Struct other) {

		other.Numero_inspection = this.Numero_inspection;
	            other.evaluation_sanitaire = this.evaluation_sanitaire;
	            other.Date_inspection = this.Date_inspection;
	            
	}

	public void copyKeysDataTo(row7Struct other) {

		other.Numero_inspection = this.Numero_inspection;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.Numero_inspection = readString(dis);
					
					this.evaluation_sanitaire = readString(dis);
					
					this.Date_inspection = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.Numero_inspection = readString(dis);
					
					this.evaluation_sanitaire = readString(dis);
					
					this.Date_inspection = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.evaluation_sanitaire,dos);
					
					// java.util.Date
				
						writeDate(this.Date_inspection,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.evaluation_sanitaire,dos);
					
					// java.util.Date
				
						writeDate(this.Date_inspection,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Numero_inspection="+Numero_inspection);
		sb.append(",evaluation_sanitaire="+evaluation_sanitaire);
		sb.append(",Date_inspection="+String.valueOf(Date_inspection));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.Numero_inspection, other.Numero_inspection);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_PROJET_DATA_projet_data_3 = new byte[0];
    static byte[] commonByteArray_PROJET_DATA_projet_data_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Long SIRET;

				public Long getSIRET () {
					return this.SIRET;
				}
				
			    public String activite_de_l_etablissement;

				public String getActivite_de_l_etablissement () {
					return this.activite_de_l_etablissement;
				}
				
			    public String nom_etablissement;

				public String getNom_etablissement () {
					return this.nom_etablissement;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.SIRET == null) ? 0 : this.SIRET.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row8Struct other = (row8Struct) obj;
		
						if (this.SIRET == null) {
							if (other.SIRET != null)
								return false;
						
						} else if (!this.SIRET.equals(other.SIRET))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row8Struct other) {

		other.SIRET = this.SIRET;
	            other.activite_de_l_etablissement = this.activite_de_l_etablissement;
	            other.nom_etablissement = this.nom_etablissement;
	            
	}

	public void copyKeysDataTo(row8Struct other) {

		other.SIRET = this.SIRET;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.SIRET = null;
           				} else {
           			    	this.SIRET = dis.readLong();
           				}
					
					this.activite_de_l_etablissement = readString(dis);
					
					this.nom_etablissement = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.SIRET = null;
           				} else {
           			    	this.SIRET = dis.readLong();
           				}
					
					this.activite_de_l_etablissement = readString(dis);
					
					this.nom_etablissement = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Long
				
						if(this.SIRET == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.SIRET);
		            	}
					
					// String
				
						writeString(this.activite_de_l_etablissement,dos);
					
					// String
				
						writeString(this.nom_etablissement,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Long
				
						if(this.SIRET == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.SIRET);
		            	}
					
					// String
				
						writeString(this.activite_de_l_etablissement,dos);
					
					// String
				
						writeString(this.nom_etablissement,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("SIRET="+String.valueOf(SIRET));
		sb.append(",activite_de_l_etablissement="+activite_de_l_etablissement);
		sb.append(",nom_etablissement="+nom_etablissement);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.SIRET, other.SIRET);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_PROJET_DATA_projet_data_3 = new byte[0];
    static byte[] commonByteArray_PROJET_DATA_projet_data_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String Adresse_etablissement;

				public String getAdresse_etablissement () {
					return this.Adresse_etablissement;
				}
				
			    public String coordonnees_geographiques;

				public String getCoordonnees_geographiques () {
					return this.coordonnees_geographiques;
				}
				
			    public String Libelle_commune;

				public String getLibelle_commune () {
					return this.Libelle_commune;
				}
				
			    public Integer Code_postal;

				public Integer getCode_postal () {
					return this.Code_postal;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.Adresse_etablissement == null) ? 0 : this.Adresse_etablissement.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row9Struct other = (row9Struct) obj;
		
						if (this.Adresse_etablissement == null) {
							if (other.Adresse_etablissement != null)
								return false;
						
						} else if (!this.Adresse_etablissement.equals(other.Adresse_etablissement))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row9Struct other) {

		other.Adresse_etablissement = this.Adresse_etablissement;
	            other.coordonnees_geographiques = this.coordonnees_geographiques;
	            other.Libelle_commune = this.Libelle_commune;
	            other.Code_postal = this.Code_postal;
	            
	}

	public void copyKeysDataTo(row9Struct other) {

		other.Adresse_etablissement = this.Adresse_etablissement;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.Adresse_etablissement = readString(dis);
					
					this.coordonnees_geographiques = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
						this.Code_postal = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.Adresse_etablissement = readString(dis);
					
					this.coordonnees_geographiques = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
						this.Code_postal = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Adresse_etablissement,dos);
					
					// String
				
						writeString(this.coordonnees_geographiques,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Adresse_etablissement,dos);
					
					// String
				
						writeString(this.coordonnees_geographiques,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Adresse_etablissement="+Adresse_etablissement);
		sb.append(",coordonnees_geographiques="+coordonnees_geographiques);
		sb.append(",Libelle_commune="+Libelle_commune);
		sb.append(",Code_postal="+String.valueOf(Code_postal));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.Adresse_etablissement, other.Adresse_etablissement);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class localisationStruct implements routines.system.IPersistableRow<localisationStruct> {
    final static byte[] commonByteArrayLock_PROJET_DATA_projet_data_3 = new byte[0];
    static byte[] commonByteArray_PROJET_DATA_projet_data_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String Adresse_etablissement;

				public String getAdresse_etablissement () {
					return this.Adresse_etablissement;
				}
				
			    public String coordonnees_geographiques;

				public String getCoordonnees_geographiques () {
					return this.coordonnees_geographiques;
				}
				
			    public String Libelle_commune;

				public String getLibelle_commune () {
					return this.Libelle_commune;
				}
				
			    public Integer Code_postal;

				public Integer getCode_postal () {
					return this.Code_postal;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.Adresse_etablissement == null) ? 0 : this.Adresse_etablissement.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final localisationStruct other = (localisationStruct) obj;
		
						if (this.Adresse_etablissement == null) {
							if (other.Adresse_etablissement != null)
								return false;
						
						} else if (!this.Adresse_etablissement.equals(other.Adresse_etablissement))
						
							return false;
					

		return true;
    }

	public void copyDataTo(localisationStruct other) {

		other.Adresse_etablissement = this.Adresse_etablissement;
	            other.coordonnees_geographiques = this.coordonnees_geographiques;
	            other.Libelle_commune = this.Libelle_commune;
	            other.Code_postal = this.Code_postal;
	            
	}

	public void copyKeysDataTo(localisationStruct other) {

		other.Adresse_etablissement = this.Adresse_etablissement;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.Adresse_etablissement = readString(dis);
					
					this.coordonnees_geographiques = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
						this.Code_postal = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.Adresse_etablissement = readString(dis);
					
					this.coordonnees_geographiques = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
						this.Code_postal = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Adresse_etablissement,dos);
					
					// String
				
						writeString(this.coordonnees_geographiques,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Adresse_etablissement,dos);
					
					// String
				
						writeString(this.coordonnees_geographiques,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Adresse_etablissement="+Adresse_etablissement);
		sb.append(",coordonnees_geographiques="+coordonnees_geographiques);
		sb.append(",Libelle_commune="+Libelle_commune);
		sb.append(",Code_postal="+String.valueOf(Code_postal));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(localisationStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.Adresse_etablissement, other.Adresse_etablissement);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class etablissementStruct implements routines.system.IPersistableRow<etablissementStruct> {
    final static byte[] commonByteArrayLock_PROJET_DATA_projet_data_3 = new byte[0];
    static byte[] commonByteArray_PROJET_DATA_projet_data_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Long SIRET;

				public Long getSIRET () {
					return this.SIRET;
				}
				
			    public String activite_de_l_etablissement;

				public String getActivite_de_l_etablissement () {
					return this.activite_de_l_etablissement;
				}
				
			    public String nom_etablissement;

				public String getNom_etablissement () {
					return this.nom_etablissement;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.SIRET == null) ? 0 : this.SIRET.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final etablissementStruct other = (etablissementStruct) obj;
		
						if (this.SIRET == null) {
							if (other.SIRET != null)
								return false;
						
						} else if (!this.SIRET.equals(other.SIRET))
						
							return false;
					

		return true;
    }

	public void copyDataTo(etablissementStruct other) {

		other.SIRET = this.SIRET;
	            other.activite_de_l_etablissement = this.activite_de_l_etablissement;
	            other.nom_etablissement = this.nom_etablissement;
	            
	}

	public void copyKeysDataTo(etablissementStruct other) {

		other.SIRET = this.SIRET;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.SIRET = null;
           				} else {
           			    	this.SIRET = dis.readLong();
           				}
					
					this.activite_de_l_etablissement = readString(dis);
					
					this.nom_etablissement = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.SIRET = null;
           				} else {
           			    	this.SIRET = dis.readLong();
           				}
					
					this.activite_de_l_etablissement = readString(dis);
					
					this.nom_etablissement = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Long
				
						if(this.SIRET == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.SIRET);
		            	}
					
					// String
				
						writeString(this.activite_de_l_etablissement,dos);
					
					// String
				
						writeString(this.nom_etablissement,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Long
				
						if(this.SIRET == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.SIRET);
		            	}
					
					// String
				
						writeString(this.activite_de_l_etablissement,dos);
					
					// String
				
						writeString(this.nom_etablissement,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("SIRET="+String.valueOf(SIRET));
		sb.append(",activite_de_l_etablissement="+activite_de_l_etablissement);
		sb.append(",nom_etablissement="+nom_etablissement);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(etablissementStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.SIRET, other.SIRET);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class inspectionsStruct implements routines.system.IPersistableRow<inspectionsStruct> {
    final static byte[] commonByteArrayLock_PROJET_DATA_projet_data_3 = new byte[0];
    static byte[] commonByteArray_PROJET_DATA_projet_data_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String Numero_inspection;

				public String getNumero_inspection () {
					return this.Numero_inspection;
				}
				
			    public String evaluation_sanitaire;

				public String getEvaluation_sanitaire () {
					return this.evaluation_sanitaire;
				}
				
			    public java.util.Date Date_inspection;

				public java.util.Date getDate_inspection () {
					return this.Date_inspection;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.Numero_inspection == null) ? 0 : this.Numero_inspection.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final inspectionsStruct other = (inspectionsStruct) obj;
		
						if (this.Numero_inspection == null) {
							if (other.Numero_inspection != null)
								return false;
						
						} else if (!this.Numero_inspection.equals(other.Numero_inspection))
						
							return false;
					

		return true;
    }

	public void copyDataTo(inspectionsStruct other) {

		other.Numero_inspection = this.Numero_inspection;
	            other.evaluation_sanitaire = this.evaluation_sanitaire;
	            other.Date_inspection = this.Date_inspection;
	            
	}

	public void copyKeysDataTo(inspectionsStruct other) {

		other.Numero_inspection = this.Numero_inspection;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.Numero_inspection = readString(dis);
					
					this.evaluation_sanitaire = readString(dis);
					
					this.Date_inspection = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.Numero_inspection = readString(dis);
					
					this.evaluation_sanitaire = readString(dis);
					
					this.Date_inspection = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.evaluation_sanitaire,dos);
					
					// java.util.Date
				
						writeDate(this.Date_inspection,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.evaluation_sanitaire,dos);
					
					// java.util.Date
				
						writeDate(this.Date_inspection,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Numero_inspection="+Numero_inspection);
		sb.append(",evaluation_sanitaire="+evaluation_sanitaire);
		sb.append(",Date_inspection="+String.valueOf(Date_inspection));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(inspectionsStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.Numero_inspection, other.Numero_inspection);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_PROJET_DATA_projet_data_3 = new byte[0];
    static byte[] commonByteArray_PROJET_DATA_projet_data_3 = new byte[0];

	
			    public String coordonnees_geographiques;

				public String getCoordonnees_geographiques () {
					return this.coordonnees_geographiques;
				}
				
			    public String activite_de_l_etablissement;

				public String getActivite_de_l_etablissement () {
					return this.activite_de_l_etablissement;
				}
				
			    public String Libelle_commune;

				public String getLibelle_commune () {
					return this.Libelle_commune;
				}
				
			    public String Date_inspection;

				public String getDate_inspection () {
					return this.Date_inspection;
				}
				
			    public String Adresse_etablissement;

				public String getAdresse_etablissement () {
					return this.Adresse_etablissement;
				}
				
			    public String nom_etablissement;

				public String getNom_etablissement () {
					return this.nom_etablissement;
				}
				
			    public String Code_postal;

				public String getCode_postal () {
					return this.Code_postal;
				}
				
			    public String SIRET;

				public String getSIRET () {
					return this.SIRET;
				}
				
			    public String Numero_inspection;

				public String getNumero_inspection () {
					return this.Numero_inspection;
				}
				
			    public String evaluation_sanitaire;

				public String getEvaluation_sanitaire () {
					return this.evaluation_sanitaire;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.coordonnees_geographiques = readString(dis);
					
					this.activite_de_l_etablissement = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
					this.Date_inspection = readString(dis);
					
					this.Adresse_etablissement = readString(dis);
					
					this.nom_etablissement = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.SIRET = readString(dis);
					
					this.Numero_inspection = readString(dis);
					
					this.evaluation_sanitaire = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.coordonnees_geographiques = readString(dis);
					
					this.activite_de_l_etablissement = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
					this.Date_inspection = readString(dis);
					
					this.Adresse_etablissement = readString(dis);
					
					this.nom_etablissement = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.SIRET = readString(dis);
					
					this.Numero_inspection = readString(dis);
					
					this.evaluation_sanitaire = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.coordonnees_geographiques,dos);
					
					// String
				
						writeString(this.activite_de_l_etablissement,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// String
				
						writeString(this.Date_inspection,dos);
					
					// String
				
						writeString(this.Adresse_etablissement,dos);
					
					// String
				
						writeString(this.nom_etablissement,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.SIRET,dos);
					
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.evaluation_sanitaire,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.coordonnees_geographiques,dos);
					
					// String
				
						writeString(this.activite_de_l_etablissement,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// String
				
						writeString(this.Date_inspection,dos);
					
					// String
				
						writeString(this.Adresse_etablissement,dos);
					
					// String
				
						writeString(this.nom_etablissement,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.SIRET,dos);
					
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.evaluation_sanitaire,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("coordonnees_geographiques="+coordonnees_geographiques);
		sb.append(",activite_de_l_etablissement="+activite_de_l_etablissement);
		sb.append(",Libelle_commune="+Libelle_commune);
		sb.append(",Date_inspection="+Date_inspection);
		sb.append(",Adresse_etablissement="+Adresse_etablissement);
		sb.append(",nom_etablissement="+nom_etablissement);
		sb.append(",Code_postal="+Code_postal);
		sb.append(",SIRET="+SIRET);
		sb.append(",Numero_inspection="+Numero_inspection);
		sb.append(",evaluation_sanitaire="+evaluation_sanitaire);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_PROJET_DATA_projet_data_3 = new byte[0];
    static byte[] commonByteArray_PROJET_DATA_projet_data_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String coordonnees_geographiques;

				public String getCoordonnees_geographiques () {
					return this.coordonnees_geographiques;
				}
				
			    public String activite_de_l_etablissement;

				public String getActivite_de_l_etablissement () {
					return this.activite_de_l_etablissement;
				}
				
			    public String Libelle_commune;

				public String getLibelle_commune () {
					return this.Libelle_commune;
				}
				
			    public String Date_inspection;

				public String getDate_inspection () {
					return this.Date_inspection;
				}
				
			    public String Adresse_etablissement;

				public String getAdresse_etablissement () {
					return this.Adresse_etablissement;
				}
				
			    public String nom_etablissement;

				public String getNom_etablissement () {
					return this.nom_etablissement;
				}
				
			    public String Code_postal;

				public String getCode_postal () {
					return this.Code_postal;
				}
				
			    public String SIRET;

				public String getSIRET () {
					return this.SIRET;
				}
				
			    public String Numero_inspection;

				public String getNumero_inspection () {
					return this.Numero_inspection;
				}
				
			    public String evaluation_sanitaire;

				public String getEvaluation_sanitaire () {
					return this.evaluation_sanitaire;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.Numero_inspection == null) ? 0 : this.Numero_inspection.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row5Struct other = (row5Struct) obj;
		
						if (this.Numero_inspection == null) {
							if (other.Numero_inspection != null)
								return false;
						
						} else if (!this.Numero_inspection.equals(other.Numero_inspection))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row5Struct other) {

		other.coordonnees_geographiques = this.coordonnees_geographiques;
	            other.activite_de_l_etablissement = this.activite_de_l_etablissement;
	            other.Libelle_commune = this.Libelle_commune;
	            other.Date_inspection = this.Date_inspection;
	            other.Adresse_etablissement = this.Adresse_etablissement;
	            other.nom_etablissement = this.nom_etablissement;
	            other.Code_postal = this.Code_postal;
	            other.SIRET = this.SIRET;
	            other.Numero_inspection = this.Numero_inspection;
	            other.evaluation_sanitaire = this.evaluation_sanitaire;
	            
	}

	public void copyKeysDataTo(row5Struct other) {

		other.Numero_inspection = this.Numero_inspection;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.coordonnees_geographiques = readString(dis);
					
					this.activite_de_l_etablissement = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
					this.Date_inspection = readString(dis);
					
					this.Adresse_etablissement = readString(dis);
					
					this.nom_etablissement = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.SIRET = readString(dis);
					
					this.Numero_inspection = readString(dis);
					
					this.evaluation_sanitaire = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.coordonnees_geographiques = readString(dis);
					
					this.activite_de_l_etablissement = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
					this.Date_inspection = readString(dis);
					
					this.Adresse_etablissement = readString(dis);
					
					this.nom_etablissement = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.SIRET = readString(dis);
					
					this.Numero_inspection = readString(dis);
					
					this.evaluation_sanitaire = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.coordonnees_geographiques,dos);
					
					// String
				
						writeString(this.activite_de_l_etablissement,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// String
				
						writeString(this.Date_inspection,dos);
					
					// String
				
						writeString(this.Adresse_etablissement,dos);
					
					// String
				
						writeString(this.nom_etablissement,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.SIRET,dos);
					
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.evaluation_sanitaire,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.coordonnees_geographiques,dos);
					
					// String
				
						writeString(this.activite_de_l_etablissement,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// String
				
						writeString(this.Date_inspection,dos);
					
					// String
				
						writeString(this.Adresse_etablissement,dos);
					
					// String
				
						writeString(this.nom_etablissement,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.SIRET,dos);
					
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.evaluation_sanitaire,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("coordonnees_geographiques="+coordonnees_geographiques);
		sb.append(",activite_de_l_etablissement="+activite_de_l_etablissement);
		sb.append(",Libelle_commune="+Libelle_commune);
		sb.append(",Date_inspection="+Date_inspection);
		sb.append(",Adresse_etablissement="+Adresse_etablissement);
		sb.append(",nom_etablissement="+nom_etablissement);
		sb.append(",Code_postal="+Code_postal);
		sb.append(",SIRET="+SIRET);
		sb.append(",Numero_inspection="+Numero_inspection);
		sb.append(",evaluation_sanitaire="+evaluation_sanitaire);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.Numero_inspection, other.Numero_inspection);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_PROJET_DATA_projet_data_3 = new byte[0];
    static byte[] commonByteArray_PROJET_DATA_projet_data_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String coordonnees_geographiques;

				public String getCoordonnees_geographiques () {
					return this.coordonnees_geographiques;
				}
				
			    public String activite_de_l_etablissement;

				public String getActivite_de_l_etablissement () {
					return this.activite_de_l_etablissement;
				}
				
			    public String Libelle_commune;

				public String getLibelle_commune () {
					return this.Libelle_commune;
				}
				
			    public String Date_inspection;

				public String getDate_inspection () {
					return this.Date_inspection;
				}
				
			    public String Adresse_etablissement;

				public String getAdresse_etablissement () {
					return this.Adresse_etablissement;
				}
				
			    public String nom_etablissement;

				public String getNom_etablissement () {
					return this.nom_etablissement;
				}
				
			    public String Code_postal;

				public String getCode_postal () {
					return this.Code_postal;
				}
				
			    public String SIRET;

				public String getSIRET () {
					return this.SIRET;
				}
				
			    public String Numero_inspection;

				public String getNumero_inspection () {
					return this.Numero_inspection;
				}
				
			    public String evaluation_sanitaire;

				public String getEvaluation_sanitaire () {
					return this.evaluation_sanitaire;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.Numero_inspection == null) ? 0 : this.Numero_inspection.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row4Struct other = (row4Struct) obj;
		
						if (this.Numero_inspection == null) {
							if (other.Numero_inspection != null)
								return false;
						
						} else if (!this.Numero_inspection.equals(other.Numero_inspection))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row4Struct other) {

		other.coordonnees_geographiques = this.coordonnees_geographiques;
	            other.activite_de_l_etablissement = this.activite_de_l_etablissement;
	            other.Libelle_commune = this.Libelle_commune;
	            other.Date_inspection = this.Date_inspection;
	            other.Adresse_etablissement = this.Adresse_etablissement;
	            other.nom_etablissement = this.nom_etablissement;
	            other.Code_postal = this.Code_postal;
	            other.SIRET = this.SIRET;
	            other.Numero_inspection = this.Numero_inspection;
	            other.evaluation_sanitaire = this.evaluation_sanitaire;
	            
	}

	public void copyKeysDataTo(row4Struct other) {

		other.Numero_inspection = this.Numero_inspection;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.coordonnees_geographiques = readString(dis);
					
					this.activite_de_l_etablissement = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
					this.Date_inspection = readString(dis);
					
					this.Adresse_etablissement = readString(dis);
					
					this.nom_etablissement = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.SIRET = readString(dis);
					
					this.Numero_inspection = readString(dis);
					
					this.evaluation_sanitaire = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.coordonnees_geographiques = readString(dis);
					
					this.activite_de_l_etablissement = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
					this.Date_inspection = readString(dis);
					
					this.Adresse_etablissement = readString(dis);
					
					this.nom_etablissement = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.SIRET = readString(dis);
					
					this.Numero_inspection = readString(dis);
					
					this.evaluation_sanitaire = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.coordonnees_geographiques,dos);
					
					// String
				
						writeString(this.activite_de_l_etablissement,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// String
				
						writeString(this.Date_inspection,dos);
					
					// String
				
						writeString(this.Adresse_etablissement,dos);
					
					// String
				
						writeString(this.nom_etablissement,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.SIRET,dos);
					
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.evaluation_sanitaire,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.coordonnees_geographiques,dos);
					
					// String
				
						writeString(this.activite_de_l_etablissement,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// String
				
						writeString(this.Date_inspection,dos);
					
					// String
				
						writeString(this.Adresse_etablissement,dos);
					
					// String
				
						writeString(this.nom_etablissement,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.SIRET,dos);
					
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.evaluation_sanitaire,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("coordonnees_geographiques="+coordonnees_geographiques);
		sb.append(",activite_de_l_etablissement="+activite_de_l_etablissement);
		sb.append(",Libelle_commune="+Libelle_commune);
		sb.append(",Date_inspection="+Date_inspection);
		sb.append(",Adresse_etablissement="+Adresse_etablissement);
		sb.append(",nom_etablissement="+nom_etablissement);
		sb.append(",Code_postal="+Code_postal);
		sb.append(",SIRET="+SIRET);
		sb.append(",Numero_inspection="+Numero_inspection);
		sb.append(",evaluation_sanitaire="+evaluation_sanitaire);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.Numero_inspection, other.Numero_inspection);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class filtre2Struct implements routines.system.IPersistableRow<filtre2Struct> {
    final static byte[] commonByteArrayLock_PROJET_DATA_projet_data_3 = new byte[0];
    static byte[] commonByteArray_PROJET_DATA_projet_data_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String coordonnees_geographiques;

				public String getCoordonnees_geographiques () {
					return this.coordonnees_geographiques;
				}
				
			    public String activite_de_l_etablissement;

				public String getActivite_de_l_etablissement () {
					return this.activite_de_l_etablissement;
				}
				
			    public String Libelle_commune;

				public String getLibelle_commune () {
					return this.Libelle_commune;
				}
				
			    public String Date_inspection;

				public String getDate_inspection () {
					return this.Date_inspection;
				}
				
			    public String Adresse_etablissement;

				public String getAdresse_etablissement () {
					return this.Adresse_etablissement;
				}
				
			    public String nom_etablissement;

				public String getNom_etablissement () {
					return this.nom_etablissement;
				}
				
			    public String Code_postal;

				public String getCode_postal () {
					return this.Code_postal;
				}
				
			    public String SIRET;

				public String getSIRET () {
					return this.SIRET;
				}
				
			    public String Numero_inspection;

				public String getNumero_inspection () {
					return this.Numero_inspection;
				}
				
			    public String evaluation_sanitaire;

				public String getEvaluation_sanitaire () {
					return this.evaluation_sanitaire;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.Numero_inspection == null) ? 0 : this.Numero_inspection.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final filtre2Struct other = (filtre2Struct) obj;
		
						if (this.Numero_inspection == null) {
							if (other.Numero_inspection != null)
								return false;
						
						} else if (!this.Numero_inspection.equals(other.Numero_inspection))
						
							return false;
					

		return true;
    }

	public void copyDataTo(filtre2Struct other) {

		other.coordonnees_geographiques = this.coordonnees_geographiques;
	            other.activite_de_l_etablissement = this.activite_de_l_etablissement;
	            other.Libelle_commune = this.Libelle_commune;
	            other.Date_inspection = this.Date_inspection;
	            other.Adresse_etablissement = this.Adresse_etablissement;
	            other.nom_etablissement = this.nom_etablissement;
	            other.Code_postal = this.Code_postal;
	            other.SIRET = this.SIRET;
	            other.Numero_inspection = this.Numero_inspection;
	            other.evaluation_sanitaire = this.evaluation_sanitaire;
	            
	}

	public void copyKeysDataTo(filtre2Struct other) {

		other.Numero_inspection = this.Numero_inspection;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.coordonnees_geographiques = readString(dis);
					
					this.activite_de_l_etablissement = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
					this.Date_inspection = readString(dis);
					
					this.Adresse_etablissement = readString(dis);
					
					this.nom_etablissement = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.SIRET = readString(dis);
					
					this.Numero_inspection = readString(dis);
					
					this.evaluation_sanitaire = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.coordonnees_geographiques = readString(dis);
					
					this.activite_de_l_etablissement = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
					this.Date_inspection = readString(dis);
					
					this.Adresse_etablissement = readString(dis);
					
					this.nom_etablissement = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.SIRET = readString(dis);
					
					this.Numero_inspection = readString(dis);
					
					this.evaluation_sanitaire = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.coordonnees_geographiques,dos);
					
					// String
				
						writeString(this.activite_de_l_etablissement,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// String
				
						writeString(this.Date_inspection,dos);
					
					// String
				
						writeString(this.Adresse_etablissement,dos);
					
					// String
				
						writeString(this.nom_etablissement,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.SIRET,dos);
					
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.evaluation_sanitaire,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.coordonnees_geographiques,dos);
					
					// String
				
						writeString(this.activite_de_l_etablissement,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// String
				
						writeString(this.Date_inspection,dos);
					
					// String
				
						writeString(this.Adresse_etablissement,dos);
					
					// String
				
						writeString(this.nom_etablissement,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.SIRET,dos);
					
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.evaluation_sanitaire,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("coordonnees_geographiques="+coordonnees_geographiques);
		sb.append(",activite_de_l_etablissement="+activite_de_l_etablissement);
		sb.append(",Libelle_commune="+Libelle_commune);
		sb.append(",Date_inspection="+Date_inspection);
		sb.append(",Adresse_etablissement="+Adresse_etablissement);
		sb.append(",nom_etablissement="+nom_etablissement);
		sb.append(",Code_postal="+Code_postal);
		sb.append(",SIRET="+SIRET);
		sb.append(",Numero_inspection="+Numero_inspection);
		sb.append(",evaluation_sanitaire="+evaluation_sanitaire);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(filtre2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.Numero_inspection, other.Numero_inspection);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class premier_filtreStruct implements routines.system.IPersistableRow<premier_filtreStruct> {
    final static byte[] commonByteArrayLock_PROJET_DATA_projet_data_3 = new byte[0];
    static byte[] commonByteArray_PROJET_DATA_projet_data_3 = new byte[0];

	
			    public String coordonnees_geographiques;

				public String getCoordonnees_geographiques () {
					return this.coordonnees_geographiques;
				}
				
			    public String activite_de_l_etablissement;

				public String getActivite_de_l_etablissement () {
					return this.activite_de_l_etablissement;
				}
				
			    public String Libelle_commune;

				public String getLibelle_commune () {
					return this.Libelle_commune;
				}
				
			    public String Date_inspection;

				public String getDate_inspection () {
					return this.Date_inspection;
				}
				
			    public String Adresse_etablissement;

				public String getAdresse_etablissement () {
					return this.Adresse_etablissement;
				}
				
			    public String nom_etablissement;

				public String getNom_etablissement () {
					return this.nom_etablissement;
				}
				
			    public String Code_postal;

				public String getCode_postal () {
					return this.Code_postal;
				}
				
			    public String SIRET;

				public String getSIRET () {
					return this.SIRET;
				}
				
			    public String Numero_inspection;

				public String getNumero_inspection () {
					return this.Numero_inspection;
				}
				
			    public String evaluation_sanitaire;

				public String getEvaluation_sanitaire () {
					return this.evaluation_sanitaire;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.coordonnees_geographiques = readString(dis);
					
					this.activite_de_l_etablissement = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
					this.Date_inspection = readString(dis);
					
					this.Adresse_etablissement = readString(dis);
					
					this.nom_etablissement = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.SIRET = readString(dis);
					
					this.Numero_inspection = readString(dis);
					
					this.evaluation_sanitaire = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.coordonnees_geographiques = readString(dis);
					
					this.activite_de_l_etablissement = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
					this.Date_inspection = readString(dis);
					
					this.Adresse_etablissement = readString(dis);
					
					this.nom_etablissement = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.SIRET = readString(dis);
					
					this.Numero_inspection = readString(dis);
					
					this.evaluation_sanitaire = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.coordonnees_geographiques,dos);
					
					// String
				
						writeString(this.activite_de_l_etablissement,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// String
				
						writeString(this.Date_inspection,dos);
					
					// String
				
						writeString(this.Adresse_etablissement,dos);
					
					// String
				
						writeString(this.nom_etablissement,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.SIRET,dos);
					
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.evaluation_sanitaire,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.coordonnees_geographiques,dos);
					
					// String
				
						writeString(this.activite_de_l_etablissement,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// String
				
						writeString(this.Date_inspection,dos);
					
					// String
				
						writeString(this.Adresse_etablissement,dos);
					
					// String
				
						writeString(this.nom_etablissement,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.SIRET,dos);
					
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.evaluation_sanitaire,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("coordonnees_geographiques="+coordonnees_geographiques);
		sb.append(",activite_de_l_etablissement="+activite_de_l_etablissement);
		sb.append(",Libelle_commune="+Libelle_commune);
		sb.append(",Date_inspection="+Date_inspection);
		sb.append(",Adresse_etablissement="+Adresse_etablissement);
		sb.append(",nom_etablissement="+nom_etablissement);
		sb.append(",Code_postal="+Code_postal);
		sb.append(",SIRET="+SIRET);
		sb.append(",Numero_inspection="+Numero_inspection);
		sb.append(",evaluation_sanitaire="+evaluation_sanitaire);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(premier_filtreStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_PROJET_DATA_projet_data_3 = new byte[0];
    static byte[] commonByteArray_PROJET_DATA_projet_data_3 = new byte[0];

	
			    public String APP_Libelle_etablissement;

				public String getAPP_Libelle_etablissement () {
					return this.APP_Libelle_etablissement;
				}
				
			    public String SIRET;

				public String getSIRET () {
					return this.SIRET;
				}
				
			    public String Adresse_2_UA;

				public String getAdresse_2_UA () {
					return this.Adresse_2_UA;
				}
				
			    public String Code_postal;

				public String getCode_postal () {
					return this.Code_postal;
				}
				
			    public String Libelle_commune;

				public String getLibelle_commune () {
					return this.Libelle_commune;
				}
				
			    public String Numero_inspection;

				public String getNumero_inspection () {
					return this.Numero_inspection;
				}
				
			    public String Date_inspection;

				public String getDate_inspection () {
					return this.Date_inspection;
				}
				
			    public String APP_Libelle_activite_etablissement;

				public String getAPP_Libelle_activite_etablissement () {
					return this.APP_Libelle_activite_etablissement;
				}
				
			    public String Synthese_eval_sanit;

				public String getSynthese_eval_sanit () {
					return this.Synthese_eval_sanit;
				}
				
			    public String Agrement;

				public String getAgrement () {
					return this.Agrement;
				}
				
			    public String geores;

				public String getGeores () {
					return this.geores;
				}
				
			    public String filtre;

				public String getFiltre () {
					return this.filtre;
				}
				
			    public String ods_type_activite;

				public String getOds_type_activite () {
					return this.ods_type_activite;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.APP_Libelle_etablissement = readString(dis);
					
					this.SIRET = readString(dis);
					
					this.Adresse_2_UA = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
					this.Numero_inspection = readString(dis);
					
					this.Date_inspection = readString(dis);
					
					this.APP_Libelle_activite_etablissement = readString(dis);
					
					this.Synthese_eval_sanit = readString(dis);
					
					this.Agrement = readString(dis);
					
					this.geores = readString(dis);
					
					this.filtre = readString(dis);
					
					this.ods_type_activite = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.APP_Libelle_etablissement = readString(dis);
					
					this.SIRET = readString(dis);
					
					this.Adresse_2_UA = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
					this.Numero_inspection = readString(dis);
					
					this.Date_inspection = readString(dis);
					
					this.APP_Libelle_activite_etablissement = readString(dis);
					
					this.Synthese_eval_sanit = readString(dis);
					
					this.Agrement = readString(dis);
					
					this.geores = readString(dis);
					
					this.filtre = readString(dis);
					
					this.ods_type_activite = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.APP_Libelle_etablissement,dos);
					
					// String
				
						writeString(this.SIRET,dos);
					
					// String
				
						writeString(this.Adresse_2_UA,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.Date_inspection,dos);
					
					// String
				
						writeString(this.APP_Libelle_activite_etablissement,dos);
					
					// String
				
						writeString(this.Synthese_eval_sanit,dos);
					
					// String
				
						writeString(this.Agrement,dos);
					
					// String
				
						writeString(this.geores,dos);
					
					// String
				
						writeString(this.filtre,dos);
					
					// String
				
						writeString(this.ods_type_activite,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.APP_Libelle_etablissement,dos);
					
					// String
				
						writeString(this.SIRET,dos);
					
					// String
				
						writeString(this.Adresse_2_UA,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.Date_inspection,dos);
					
					// String
				
						writeString(this.APP_Libelle_activite_etablissement,dos);
					
					// String
				
						writeString(this.Synthese_eval_sanit,dos);
					
					// String
				
						writeString(this.Agrement,dos);
					
					// String
				
						writeString(this.geores,dos);
					
					// String
				
						writeString(this.filtre,dos);
					
					// String
				
						writeString(this.ods_type_activite,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("APP_Libelle_etablissement="+APP_Libelle_etablissement);
		sb.append(",SIRET="+SIRET);
		sb.append(",Adresse_2_UA="+Adresse_2_UA);
		sb.append(",Code_postal="+Code_postal);
		sb.append(",Libelle_commune="+Libelle_commune);
		sb.append(",Numero_inspection="+Numero_inspection);
		sb.append(",Date_inspection="+Date_inspection);
		sb.append(",APP_Libelle_activite_etablissement="+APP_Libelle_activite_etablissement);
		sb.append(",Synthese_eval_sanit="+Synthese_eval_sanit);
		sb.append(",Agrement="+Agrement);
		sb.append(",geores="+geores);
		sb.append(",filtre="+filtre);
		sb.append(",ods_type_activite="+ods_type_activite);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_PROJET_DATA_projet_data_3 = new byte[0];
    static byte[] commonByteArray_PROJET_DATA_projet_data_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String APP_Libelle_etablissement;

				public String getAPP_Libelle_etablissement () {
					return this.APP_Libelle_etablissement;
				}
				
			    public String SIRET;

				public String getSIRET () {
					return this.SIRET;
				}
				
			    public String Adresse_2_UA;

				public String getAdresse_2_UA () {
					return this.Adresse_2_UA;
				}
				
			    public String Code_postal;

				public String getCode_postal () {
					return this.Code_postal;
				}
				
			    public String Libelle_commune;

				public String getLibelle_commune () {
					return this.Libelle_commune;
				}
				
			    public String Numero_inspection;

				public String getNumero_inspection () {
					return this.Numero_inspection;
				}
				
			    public String Date_inspection;

				public String getDate_inspection () {
					return this.Date_inspection;
				}
				
			    public String APP_Libelle_activite_etablissement;

				public String getAPP_Libelle_activite_etablissement () {
					return this.APP_Libelle_activite_etablissement;
				}
				
			    public String Synthese_eval_sanit;

				public String getSynthese_eval_sanit () {
					return this.Synthese_eval_sanit;
				}
				
			    public String Agrement;

				public String getAgrement () {
					return this.Agrement;
				}
				
			    public String geores;

				public String getGeores () {
					return this.geores;
				}
				
			    public String filtre;

				public String getFiltre () {
					return this.filtre;
				}
				
			    public String ods_type_activite;

				public String getOds_type_activite () {
					return this.ods_type_activite;
				}
				
			    public String errorMessage;

				public String getErrorMessage () {
					return this.errorMessage;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.Numero_inspection == null) ? 0 : this.Numero_inspection.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row3Struct other = (row3Struct) obj;
		
						if (this.Numero_inspection == null) {
							if (other.Numero_inspection != null)
								return false;
						
						} else if (!this.Numero_inspection.equals(other.Numero_inspection))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row3Struct other) {

		other.APP_Libelle_etablissement = this.APP_Libelle_etablissement;
	            other.SIRET = this.SIRET;
	            other.Adresse_2_UA = this.Adresse_2_UA;
	            other.Code_postal = this.Code_postal;
	            other.Libelle_commune = this.Libelle_commune;
	            other.Numero_inspection = this.Numero_inspection;
	            other.Date_inspection = this.Date_inspection;
	            other.APP_Libelle_activite_etablissement = this.APP_Libelle_activite_etablissement;
	            other.Synthese_eval_sanit = this.Synthese_eval_sanit;
	            other.Agrement = this.Agrement;
	            other.geores = this.geores;
	            other.filtre = this.filtre;
	            other.ods_type_activite = this.ods_type_activite;
	            other.errorMessage = this.errorMessage;
	            
	}

	public void copyKeysDataTo(row3Struct other) {

		other.Numero_inspection = this.Numero_inspection;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.APP_Libelle_etablissement = readString(dis);
					
					this.SIRET = readString(dis);
					
					this.Adresse_2_UA = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
					this.Numero_inspection = readString(dis);
					
					this.Date_inspection = readString(dis);
					
					this.APP_Libelle_activite_etablissement = readString(dis);
					
					this.Synthese_eval_sanit = readString(dis);
					
					this.Agrement = readString(dis);
					
					this.geores = readString(dis);
					
					this.filtre = readString(dis);
					
					this.ods_type_activite = readString(dis);
					
					this.errorMessage = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.APP_Libelle_etablissement = readString(dis);
					
					this.SIRET = readString(dis);
					
					this.Adresse_2_UA = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
					this.Numero_inspection = readString(dis);
					
					this.Date_inspection = readString(dis);
					
					this.APP_Libelle_activite_etablissement = readString(dis);
					
					this.Synthese_eval_sanit = readString(dis);
					
					this.Agrement = readString(dis);
					
					this.geores = readString(dis);
					
					this.filtre = readString(dis);
					
					this.ods_type_activite = readString(dis);
					
					this.errorMessage = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.APP_Libelle_etablissement,dos);
					
					// String
				
						writeString(this.SIRET,dos);
					
					// String
				
						writeString(this.Adresse_2_UA,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.Date_inspection,dos);
					
					// String
				
						writeString(this.APP_Libelle_activite_etablissement,dos);
					
					// String
				
						writeString(this.Synthese_eval_sanit,dos);
					
					// String
				
						writeString(this.Agrement,dos);
					
					// String
				
						writeString(this.geores,dos);
					
					// String
				
						writeString(this.filtre,dos);
					
					// String
				
						writeString(this.ods_type_activite,dos);
					
					// String
				
						writeString(this.errorMessage,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.APP_Libelle_etablissement,dos);
					
					// String
				
						writeString(this.SIRET,dos);
					
					// String
				
						writeString(this.Adresse_2_UA,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.Date_inspection,dos);
					
					// String
				
						writeString(this.APP_Libelle_activite_etablissement,dos);
					
					// String
				
						writeString(this.Synthese_eval_sanit,dos);
					
					// String
				
						writeString(this.Agrement,dos);
					
					// String
				
						writeString(this.geores,dos);
					
					// String
				
						writeString(this.filtre,dos);
					
					// String
				
						writeString(this.ods_type_activite,dos);
					
					// String
				
						writeString(this.errorMessage,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("APP_Libelle_etablissement="+APP_Libelle_etablissement);
		sb.append(",SIRET="+SIRET);
		sb.append(",Adresse_2_UA="+Adresse_2_UA);
		sb.append(",Code_postal="+Code_postal);
		sb.append(",Libelle_commune="+Libelle_commune);
		sb.append(",Numero_inspection="+Numero_inspection);
		sb.append(",Date_inspection="+Date_inspection);
		sb.append(",APP_Libelle_activite_etablissement="+APP_Libelle_activite_etablissement);
		sb.append(",Synthese_eval_sanit="+Synthese_eval_sanit);
		sb.append(",Agrement="+Agrement);
		sb.append(",geores="+geores);
		sb.append(",filtre="+filtre);
		sb.append(",ods_type_activite="+ods_type_activite);
		sb.append(",errorMessage="+errorMessage);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.Numero_inspection, other.Numero_inspection);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_PROJET_DATA_projet_data_3 = new byte[0];
    static byte[] commonByteArray_PROJET_DATA_projet_data_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String APP_Libelle_etablissement;

				public String getAPP_Libelle_etablissement () {
					return this.APP_Libelle_etablissement;
				}
				
			    public String SIRET;

				public String getSIRET () {
					return this.SIRET;
				}
				
			    public String Adresse_2_UA;

				public String getAdresse_2_UA () {
					return this.Adresse_2_UA;
				}
				
			    public String Code_postal;

				public String getCode_postal () {
					return this.Code_postal;
				}
				
			    public String Libelle_commune;

				public String getLibelle_commune () {
					return this.Libelle_commune;
				}
				
			    public String Numero_inspection;

				public String getNumero_inspection () {
					return this.Numero_inspection;
				}
				
			    public String Date_inspection;

				public String getDate_inspection () {
					return this.Date_inspection;
				}
				
			    public String APP_Libelle_activite_etablissement;

				public String getAPP_Libelle_activite_etablissement () {
					return this.APP_Libelle_activite_etablissement;
				}
				
			    public String Synthese_eval_sanit;

				public String getSynthese_eval_sanit () {
					return this.Synthese_eval_sanit;
				}
				
			    public String Agrement;

				public String getAgrement () {
					return this.Agrement;
				}
				
			    public String geores;

				public String getGeores () {
					return this.geores;
				}
				
			    public String filtre;

				public String getFiltre () {
					return this.filtre;
				}
				
			    public String ods_type_activite;

				public String getOds_type_activite () {
					return this.ods_type_activite;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.Numero_inspection == null) ? 0 : this.Numero_inspection.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row2Struct other = (row2Struct) obj;
		
						if (this.Numero_inspection == null) {
							if (other.Numero_inspection != null)
								return false;
						
						} else if (!this.Numero_inspection.equals(other.Numero_inspection))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row2Struct other) {

		other.APP_Libelle_etablissement = this.APP_Libelle_etablissement;
	            other.SIRET = this.SIRET;
	            other.Adresse_2_UA = this.Adresse_2_UA;
	            other.Code_postal = this.Code_postal;
	            other.Libelle_commune = this.Libelle_commune;
	            other.Numero_inspection = this.Numero_inspection;
	            other.Date_inspection = this.Date_inspection;
	            other.APP_Libelle_activite_etablissement = this.APP_Libelle_activite_etablissement;
	            other.Synthese_eval_sanit = this.Synthese_eval_sanit;
	            other.Agrement = this.Agrement;
	            other.geores = this.geores;
	            other.filtre = this.filtre;
	            other.ods_type_activite = this.ods_type_activite;
	            
	}

	public void copyKeysDataTo(row2Struct other) {

		other.Numero_inspection = this.Numero_inspection;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_PROJET_DATA_projet_data_3.length) {
				if(length < 1024 && commonByteArray_PROJET_DATA_projet_data_3.length == 0) {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[1024];
				} else {
   					commonByteArray_PROJET_DATA_projet_data_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_PROJET_DATA_projet_data_3, 0, length);
			strReturn = new String(commonByteArray_PROJET_DATA_projet_data_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.APP_Libelle_etablissement = readString(dis);
					
					this.SIRET = readString(dis);
					
					this.Adresse_2_UA = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
					this.Numero_inspection = readString(dis);
					
					this.Date_inspection = readString(dis);
					
					this.APP_Libelle_activite_etablissement = readString(dis);
					
					this.Synthese_eval_sanit = readString(dis);
					
					this.Agrement = readString(dis);
					
					this.geores = readString(dis);
					
					this.filtre = readString(dis);
					
					this.ods_type_activite = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_PROJET_DATA_projet_data_3) {

        	try {

        		int length = 0;
		
					this.APP_Libelle_etablissement = readString(dis);
					
					this.SIRET = readString(dis);
					
					this.Adresse_2_UA = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.Libelle_commune = readString(dis);
					
					this.Numero_inspection = readString(dis);
					
					this.Date_inspection = readString(dis);
					
					this.APP_Libelle_activite_etablissement = readString(dis);
					
					this.Synthese_eval_sanit = readString(dis);
					
					this.Agrement = readString(dis);
					
					this.geores = readString(dis);
					
					this.filtre = readString(dis);
					
					this.ods_type_activite = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.APP_Libelle_etablissement,dos);
					
					// String
				
						writeString(this.SIRET,dos);
					
					// String
				
						writeString(this.Adresse_2_UA,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.Date_inspection,dos);
					
					// String
				
						writeString(this.APP_Libelle_activite_etablissement,dos);
					
					// String
				
						writeString(this.Synthese_eval_sanit,dos);
					
					// String
				
						writeString(this.Agrement,dos);
					
					// String
				
						writeString(this.geores,dos);
					
					// String
				
						writeString(this.filtre,dos);
					
					// String
				
						writeString(this.ods_type_activite,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.APP_Libelle_etablissement,dos);
					
					// String
				
						writeString(this.SIRET,dos);
					
					// String
				
						writeString(this.Adresse_2_UA,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.Libelle_commune,dos);
					
					// String
				
						writeString(this.Numero_inspection,dos);
					
					// String
				
						writeString(this.Date_inspection,dos);
					
					// String
				
						writeString(this.APP_Libelle_activite_etablissement,dos);
					
					// String
				
						writeString(this.Synthese_eval_sanit,dos);
					
					// String
				
						writeString(this.Agrement,dos);
					
					// String
				
						writeString(this.geores,dos);
					
					// String
				
						writeString(this.filtre,dos);
					
					// String
				
						writeString(this.ods_type_activite,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("APP_Libelle_etablissement="+APP_Libelle_etablissement);
		sb.append(",SIRET="+SIRET);
		sb.append(",Adresse_2_UA="+Adresse_2_UA);
		sb.append(",Code_postal="+Code_postal);
		sb.append(",Libelle_commune="+Libelle_commune);
		sb.append(",Numero_inspection="+Numero_inspection);
		sb.append(",Date_inspection="+Date_inspection);
		sb.append(",APP_Libelle_activite_etablissement="+APP_Libelle_activite_etablissement);
		sb.append(",Synthese_eval_sanit="+Synthese_eval_sanit);
		sb.append(",Agrement="+Agrement);
		sb.append(",geores="+geores);
		sb.append(",filtre="+filtre);
		sb.append(",ods_type_activite="+ods_type_activite);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.Numero_inspection, other.Numero_inspection);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();
row1Struct row1 = new row1Struct();
premier_filtreStruct premier_filtre = new premier_filtreStruct();
filtre2Struct filtre2 = new filtre2Struct();
row4Struct row4 = new row4Struct();
row5Struct row5 = new row5Struct();
row6Struct row6 = new row6Struct();
localisationStruct localisation = new localisationStruct();
row9Struct row9 = new row9Struct();
etablissementStruct etablissement = new etablissementStruct();
row8Struct row8 = new row8Struct();
inspectionsStruct inspections = new inspectionsStruct();
row7Struct row7 = new row7Struct();
row3Struct row3 = new row3Struct();












	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row9");
					}
				
		int tos_count_tDBOutput_1 = 0;
		
	




int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;

String tableName_tDBOutput_1 = "localisation";
boolean whetherReject_tDBOutput_1 = false;

       int batchSize_tDBOutput_1 = 10000;
       int batchSizeCounter_tDBOutput_1=0;
       int tmp_batchUpdateCount_tDBOutput_1 = 0;



java.sql.Connection conn_tDBOutput_1 = null;
    conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");

            try (java.sql.Statement stmtClear_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
                deletedCount_tDBOutput_1 = deletedCount_tDBOutput_1 + stmtClear_tDBOutput_1.executeUpdate("DELETE FROM \"" + tableName_tDBOutput_1 + "\"");
            }
	    String insert_tDBOutput_1 = "INSERT INTO \"" + "localisation" + "\" (\"Adresse_etablissement\",\"coordonnees_geographiques\",\"Libelle_commune\",\"Code_postal\") VALUES (?,?,?,?)";
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tUniqRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_2", false);
		start_Hash.put("tUniqRow_2", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"localisation");
					}
				
		int tos_count_tUniqRow_2 = 0;
		

	
		class KeyStruct_tUniqRow_2 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					String Adresse_etablissement;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.Adresse_etablissement == null) ? 0 : this.Adresse_etablissement.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_2 other = (KeyStruct_tUniqRow_2) obj;
				
									if (this.Adresse_etablissement == null) {
										if (other.Adresse_etablissement != null) 
											return false;
								
									} else if (!this.Adresse_etablissement.equals(other.Adresse_etablissement))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_2 = 0;
int nb_duplicates_tUniqRow_2 = 0;
KeyStruct_tUniqRow_2 finder_tUniqRow_2 = new KeyStruct_tUniqRow_2();
java.util.Set<KeyStruct_tUniqRow_2> keystUniqRow_2 = new java.util.HashSet<KeyStruct_tUniqRow_2>(); 

 



/**
 * [tUniqRow_2 begin ] stop
 */





	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row8");
					}
				
		int tos_count_tDBOutput_2 = 0;
		
	




int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;

String tableName_tDBOutput_2 = "etablissement";
boolean whetherReject_tDBOutput_2 = false;

       int batchSize_tDBOutput_2 = 10000;
       int batchSizeCounter_tDBOutput_2=0;
       int tmp_batchUpdateCount_tDBOutput_2 = 0;



java.sql.Connection conn_tDBOutput_2 = null;
    conn_tDBOutput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");

            try (java.sql.Statement stmtClear_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
                deletedCount_tDBOutput_2 = deletedCount_tDBOutput_2 + stmtClear_tDBOutput_2.executeUpdate("DELETE FROM \"" + tableName_tDBOutput_2 + "\"");
            }
	    String insert_tDBOutput_2 = "INSERT INTO \"" + "etablissement" + "\" (\"SIRET\",\"activite_de_l_etablissement\",\"nom_etablissement\") VALUES (?,?,?)";
	    java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
	    resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
	    

 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tUniqRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_3", false);
		start_Hash.put("tUniqRow_3", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_3";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"etablissement");
					}
				
		int tos_count_tUniqRow_3 = 0;
		

	
		class KeyStruct_tUniqRow_3 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					Long SIRET;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.SIRET == null) ? 0 : this.SIRET.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_3 other = (KeyStruct_tUniqRow_3) obj;
				
									if (this.SIRET == null) {
										if (other.SIRET != null) 
											return false;
								
									} else if (!this.SIRET.equals(other.SIRET))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_3 = 0;
int nb_duplicates_tUniqRow_3 = 0;
KeyStruct_tUniqRow_3 finder_tUniqRow_3 = new KeyStruct_tUniqRow_3();
java.util.Set<KeyStruct_tUniqRow_3> keystUniqRow_3 = new java.util.HashSet<KeyStruct_tUniqRow_3>(); 

 



/**
 * [tUniqRow_3 begin ] stop
 */





	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_3";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row7");
					}
				
		int tos_count_tDBOutput_3 = 0;
		
	




int nb_line_tDBOutput_3 = 0;
int nb_line_update_tDBOutput_3 = 0;
int nb_line_inserted_tDBOutput_3 = 0;
int nb_line_deleted_tDBOutput_3 = 0;
int nb_line_rejected_tDBOutput_3 = 0;

int deletedCount_tDBOutput_3=0;
int updatedCount_tDBOutput_3=0;
int insertedCount_tDBOutput_3=0;
int rowsToCommitCount_tDBOutput_3=0;

String tableName_tDBOutput_3 = "inspections";
boolean whetherReject_tDBOutput_3 = false;

       int batchSize_tDBOutput_3 = 10000;
       int batchSizeCounter_tDBOutput_3=0;
       int tmp_batchUpdateCount_tDBOutput_3 = 0;



java.sql.Connection conn_tDBOutput_3 = null;
    conn_tDBOutput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");

            try (java.sql.Statement stmtClear_tDBOutput_3 = conn_tDBOutput_3.createStatement()) {
                deletedCount_tDBOutput_3 = deletedCount_tDBOutput_3 + stmtClear_tDBOutput_3.executeUpdate("DELETE FROM \"" + tableName_tDBOutput_3 + "\"");
            }
	    String insert_tDBOutput_3 = "INSERT INTO \"" + "inspections" + "\" (\"Numero_inspection\",\"evaluation_sanitaire\",\"Date_inspection\") VALUES (?,?,?)";
	    java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
	    resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);
	    

 



/**
 * [tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tUniqRow_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_4", false);
		start_Hash.put("tUniqRow_4", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_4";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"inspections");
					}
				
		int tos_count_tUniqRow_4 = 0;
		

	
		class KeyStruct_tUniqRow_4 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					String Numero_inspection;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.Numero_inspection == null) ? 0 : this.Numero_inspection.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_4 other = (KeyStruct_tUniqRow_4) obj;
				
									if (this.Numero_inspection == null) {
										if (other.Numero_inspection != null) 
											return false;
								
									} else if (!this.Numero_inspection.equals(other.Numero_inspection))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_4 = 0;
int nb_duplicates_tUniqRow_4 = 0;
KeyStruct_tUniqRow_4 finder_tUniqRow_4 = new KeyStruct_tUniqRow_4();
java.util.Set<KeyStruct_tUniqRow_4> keystUniqRow_4 = new java.util.HashSet<KeyStruct_tUniqRow_4>(); 

 



/**
 * [tUniqRow_4 begin ] stop
 */



	
	/**
	 * [tMap_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_3", false);
		start_Hash.put("tMap_3", System.currentTimeMillis());
		
	
	currentComponent="tMap_3";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row6");
					}
				
		int tos_count_tMap_3 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_3__Struct  {
}
Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
localisationStruct localisation_tmp = new localisationStruct();
etablissementStruct etablissement_tmp = new etablissementStruct();
inspectionsStruct inspections_tmp = new inspectionsStruct();
// ###############################

        
        



        









 



/**
 * [tMap_3 begin ] stop
 */



	
	/**
	 * [tUniqRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_1", false);
		start_Hash.put("tUniqRow_1", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row5");
					}
				
		int tos_count_tUniqRow_1 = 0;
		

	
		class KeyStruct_tUniqRow_1 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					String Numero_inspection;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.Numero_inspection == null) ? 0 : this.Numero_inspection.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_1 other = (KeyStruct_tUniqRow_1) obj;
				
									if (this.Numero_inspection == null) {
										if (other.Numero_inspection != null) 
											return false;
								
									} else if (!this.Numero_inspection.equals(other.Numero_inspection))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_1 = 0;
int nb_duplicates_tUniqRow_1 = 0;
KeyStruct_tUniqRow_1 finder_tUniqRow_1 = new KeyStruct_tUniqRow_1();
java.util.Set<KeyStruct_tUniqRow_1> keystUniqRow_1 = new java.util.HashSet<KeyStruct_tUniqRow_1>(); 

 



/**
 * [tUniqRow_1 begin ] stop
 */



	
	/**
	 * [tFilterRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterRow_3", false);
		start_Hash.put("tFilterRow_3", System.currentTimeMillis());
		
	
	currentComponent="tFilterRow_3";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row4");
					}
				
		int tos_count_tFilterRow_3 = 0;
		
    int nb_line_tFilterRow_3 = 0;
    int nb_line_ok_tFilterRow_3 = 0;
    int nb_line_reject_tFilterRow_3 = 0;

    class Operator_tFilterRow_3 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_tFilterRow_3(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [tFilterRow_3 begin ] stop
 */



	
	/**
	 * [tFilterRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterRow_2", false);
		start_Hash.put("tFilterRow_2", System.currentTimeMillis());
		
	
	currentComponent="tFilterRow_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"filtre2");
					}
				
		int tos_count_tFilterRow_2 = 0;
		
    int nb_line_tFilterRow_2 = 0;
    int nb_line_ok_tFilterRow_2 = 0;
    int nb_line_reject_tFilterRow_2 = 0;

    class Operator_tFilterRow_2 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_tFilterRow_2(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [tFilterRow_2 begin ] stop
 */



	
	/**
	 * [tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_2", false);
		start_Hash.put("tMap_2", System.currentTimeMillis());
		
	
	currentComponent="tMap_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"premier_filtre");
					}
				
		int tos_count_tMap_2 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_2__Struct  {
}
Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
filtre2Struct filtre2_tmp = new filtre2Struct();
// ###############################

        
        



        









 



/**
 * [tMap_2 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row1");
					}
				
		int tos_count_tMap_1 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
premier_filtreStruct premier_filtre_tmp = new premier_filtreStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */




	
	/**
	 * [tLogRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_2", false);
		start_Hash.put("tLogRow_2", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row3");
					}
				
		int tos_count_tLogRow_2 = 0;
		

	///////////////////////
	
         class Util_tLogRow_2 {

        String[] des_top = { ".", ".", "-", "+" };

        String[] des_head = { "|=", "=|", "-", "+" };

        String[] des_bottom = { "'", "'", "-", "+" };

        String name="";

        java.util.List<String[]> list = new java.util.ArrayList<String[]>();

        int[] colLengths = new int[14];

        public void addRow(String[] row) {

            for (int i = 0; i < 14; i++) {
                if (row[i]!=null) {
                  colLengths[i] = Math.max(colLengths[i], row[i].length());
                }
            }
            list.add(row);
        }

        public void setTableName(String name) {

            this.name = name;
        }

            public StringBuilder format() {
            
                StringBuilder sb = new StringBuilder();
  
            
                    sb.append(print(des_top));
    
                    int totals = 0;
                    for (int i = 0; i < colLengths.length; i++) {
                        totals = totals + colLengths[i];
                    }
    
                    // name
                    sb.append("|");
                    int k = 0;
                    for (k = 0; k < (totals + 13 - name.length()) / 2; k++) {
                        sb.append(' ');
                    }
                    sb.append(name);
                    for (int i = 0; i < totals + 13 - name.length() - k; i++) {
                        sb.append(' ');
                    }
                    sb.append("|\n");

                    // head and rows
                    sb.append(print(des_head));
                    for (int i = 0; i < list.size(); i++) {
    
                        String[] row = list.get(i);
    
                        java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());
                        
                        StringBuilder sbformat = new StringBuilder();                                             
        			        sbformat.append("|%1$-");
        			        sbformat.append(colLengths[0]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%2$-");
        			        sbformat.append(colLengths[1]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%3$-");
        			        sbformat.append(colLengths[2]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%4$-");
        			        sbformat.append(colLengths[3]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%5$-");
        			        sbformat.append(colLengths[4]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%6$-");
        			        sbformat.append(colLengths[5]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%7$-");
        			        sbformat.append(colLengths[6]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%8$-");
        			        sbformat.append(colLengths[7]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%9$-");
        			        sbformat.append(colLengths[8]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%10$-");
        			        sbformat.append(colLengths[9]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%11$-");
        			        sbformat.append(colLengths[10]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%12$-");
        			        sbformat.append(colLengths[11]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%13$-");
        			        sbformat.append(colLengths[12]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%14$-");
        			        sbformat.append(colLengths[13]);
        			        sbformat.append("s");
        			                      
                        sbformat.append("|\n");                    
       
                        formatter.format(sbformat.toString(), (Object[])row);	
                                
                        sb.append(formatter.toString());
                        if (i == 0)
                            sb.append(print(des_head)); // print the head
                    }
    
                    // end
                    sb.append(print(des_bottom));
                    return sb;
                }
            

            private StringBuilder print(String[] fillChars) {
                StringBuilder sb = new StringBuilder();
                //first column
                sb.append(fillChars[0]);                
                    for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);	                

                    for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[9] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[10] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[11] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[12] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                
                    //last column
                    for (int i = 0; i < colLengths[13] - fillChars[1].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }         
                sb.append(fillChars[1]);
                sb.append("\n");               
                return sb;
            }
            
            public boolean isTableEmpty(){
            	if (list.size() > 1)
            		return false;
            	return true;
            }
        }
        Util_tLogRow_2 util_tLogRow_2 = new Util_tLogRow_2();
        util_tLogRow_2.setTableName("tLogRow_2");
        util_tLogRow_2.addRow(new String[]{"APP_Libelle_etablissement","SIRET","Adresse_2_UA","Code_postal","Libelle_commune","Numero_inspection","Date_inspection","APP_Libelle_activite_etablissement","Synthese_eval_sanit","Agrement","geores","filtre","ods_type_activite","errorMessage",});        
 		StringBuilder strBuffer_tLogRow_2 = null;
		int nb_line_tLogRow_2 = 0;
///////////////////////    			



 



/**
 * [tLogRow_2 begin ] stop
 */



	
	/**
	 * [tFilterRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterRow_1", false);
		start_Hash.put("tFilterRow_1", System.currentTimeMillis());
		
	
	currentComponent="tFilterRow_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row2");
					}
				
		int tos_count_tFilterRow_1 = 0;
		
    int nb_line_tFilterRow_1 = 0;
    int nb_line_ok_tFilterRow_1 = 0;
    int nb_line_reject_tFilterRow_1 = 0;

    class Operator_tFilterRow_1 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_tFilterRow_1(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [tFilterRow_1 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_1", false);
		start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_1";

	
		int tos_count_tFileInputDelimited_1 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				int limit_tFileInputDelimited_1 = -1;
				try{
					
						Object filename_tFileInputDelimited_1 = context.context_alimconfiance_File;
						if(filename_tFileInputDelimited_1 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
			if(footer_value_tFileInputDelimited_1 >0 || random_value_tFileInputDelimited_1 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited(context.context_alimconfiance_File, context.context_alimconfiance_Encoding,context.context_alimconfiance_FieldSeparator,context.context_alimconfiance_RowSeparator,false,context.context_alimconfiance_Header,0,
									limit_tFileInputDelimited_1
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",e.getMessage());
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_1!=null && fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();
						
			    						row2 = null;			
												
									boolean whetherReject_tFileInputDelimited_1 = false;
									row2 = new row2Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_1 = 0;
				
					columnIndexWithD_tFileInputDelimited_1 = 0;
					
							row2.APP_Libelle_etablissement = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 1;
					
							row2.SIRET = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 2;
					
							row2.Adresse_2_UA = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 3;
					
							row2.Code_postal = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 4;
					
							row2.Libelle_commune = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 5;
					
							row2.Numero_inspection = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 6;
					
							row2.Date_inspection = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 7;
					
							row2.APP_Libelle_activite_etablissement = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 8;
					
							row2.Synthese_eval_sanit = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 9;
					
							row2.Agrement = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 10;
					
							row2.geores = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 11;
					
							row2.filtre = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 12;
					
							row2.ods_type_activite = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
				
										
										if(rowstate_tFileInputDelimited_1.getException()!=null) {
											throw rowstate_tFileInputDelimited_1.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_1 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row2 = null;
			                				
										
			    					}
								

 



/**
 * [tFileInputDelimited_1 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 


	tos_count_tFileInputDelimited_1++;

/**
 * [tFileInputDelimited_1 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 process_data_begin ] stop
 */
// Start of branch "row2"
if(row2 != null) { 
			row3 = null;



	
	/**
	 * [tFilterRow_1 main ] start
	 */

	

	
	
	currentComponent="tFilterRow_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row2"
						
						);
					}
					

          row3 = null;
          row1 = null;
    Operator_tFilterRow_1 ope_tFilterRow_1 = new Operator_tFilterRow_1("&&");    
        ope_tFilterRow_1.matches((row2.Date_inspection == null? false : row2.Date_inspection.length() >= 10)
                       , " Date_inspection.length() >= 10 failed");
    
    if (ope_tFilterRow_1.getMatchFlag()) {
              if(row1 == null){ 
                row1 = new row1Struct();
              }
               row1.APP_Libelle_etablissement = row2.APP_Libelle_etablissement;
               row1.SIRET = row2.SIRET;
               row1.Adresse_2_UA = row2.Adresse_2_UA;
               row1.Code_postal = row2.Code_postal;
               row1.Libelle_commune = row2.Libelle_commune;
               row1.Numero_inspection = row2.Numero_inspection;
               row1.Date_inspection = row2.Date_inspection;
               row1.APP_Libelle_activite_etablissement = row2.APP_Libelle_activite_etablissement;
               row1.Synthese_eval_sanit = row2.Synthese_eval_sanit;
               row1.Agrement = row2.Agrement;
               row1.geores = row2.geores;
               row1.filtre = row2.filtre;
               row1.ods_type_activite = row2.ods_type_activite;    
      nb_line_ok_tFilterRow_1++;
    } else {
            if (row3 == null){
              row3 = new row3Struct();
            }
                row3.APP_Libelle_etablissement = row2.APP_Libelle_etablissement;
                row3.SIRET = row2.SIRET;
                row3.Adresse_2_UA = row2.Adresse_2_UA;
                row3.Code_postal = row2.Code_postal;
                row3.Libelle_commune = row2.Libelle_commune;
                row3.Numero_inspection = row2.Numero_inspection;
                row3.Date_inspection = row2.Date_inspection;
                row3.APP_Libelle_activite_etablissement = row2.APP_Libelle_activite_etablissement;
                row3.Synthese_eval_sanit = row2.Synthese_eval_sanit;
                row3.Agrement = row2.Agrement;
                row3.geores = row2.geores;
                row3.filtre = row2.filtre;
                row3.ods_type_activite = row2.ods_type_activite;
	            row3.errorMessage = ope_tFilterRow_1.getErrorMsg();
      nb_line_reject_tFilterRow_1++;
    }

nb_line_tFilterRow_1++;

 


	tos_count_tFilterRow_1++;

/**
 * [tFilterRow_1 main ] stop
 */
	
	/**
	 * [tFilterRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFilterRow_1";

	

 



/**
 * [tFilterRow_1 process_data_begin ] stop
 */
// Start of branch "row1"
if(row1 != null) { 



	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row1"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

premier_filtre = null;


// # Output table : 'premier_filtre'
premier_filtre_tmp.coordonnees_geographiques = StringHandling.EREPLACE(row1.geores, "[^0-9|,|.|-]", "");
premier_filtre_tmp.activite_de_l_etablissement = row1.APP_Libelle_activite_etablissement ;
premier_filtre_tmp.Libelle_commune = row1.Libelle_commune ;
premier_filtre_tmp.Date_inspection = row1.Date_inspection.substring(0,10);
premier_filtre_tmp.Adresse_etablissement = row1.Adresse_2_UA ;
premier_filtre_tmp.nom_etablissement = row1.APP_Libelle_etablissement ;
premier_filtre_tmp.Code_postal = StringHandling.EREPLACE(row1.Code_postal, "[^0-9]", "");
premier_filtre_tmp.SIRET = StringHandling.EREPLACE(row1.SIRET, "[^0-9]", "");
premier_filtre_tmp.Numero_inspection = row1.Numero_inspection ;
premier_filtre_tmp.evaluation_sanitaire = row1.Synthese_eval_sanit ;
premier_filtre = premier_filtre_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "premier_filtre"
if(premier_filtre != null) { 



	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"premier_filtre"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_2 = false;
		  boolean mainRowRejected_tMap_2 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
        // ###############################
        // # Output tables

filtre2 = null;


// # Output table : 'filtre2'
filtre2_tmp.coordonnees_geographiques = premier_filtre.coordonnees_geographiques ;
filtre2_tmp.activite_de_l_etablissement = premier_filtre.activite_de_l_etablissement ;
filtre2_tmp.Libelle_commune = premier_filtre.Libelle_commune ;
filtre2_tmp.Date_inspection = StringHandling.EREPLACE(premier_filtre.Date_inspection, "[^0-9|-]", "")   ;
filtre2_tmp.Adresse_etablissement = premier_filtre.Adresse_etablissement ;
filtre2_tmp.nom_etablissement = premier_filtre.nom_etablissement ;
filtre2_tmp.Code_postal = premier_filtre.Code_postal ;
filtre2_tmp.SIRET = premier_filtre.SIRET ;
filtre2_tmp.Numero_inspection = premier_filtre.Numero_inspection ;
filtre2_tmp.evaluation_sanitaire = premier_filtre.evaluation_sanitaire ;
filtre2 = filtre2_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
	
	/**
	 * [tMap_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 process_data_begin ] stop
 */
// Start of branch "filtre2"
if(filtre2 != null) { 



	
	/**
	 * [tFilterRow_2 main ] start
	 */

	

	
	
	currentComponent="tFilterRow_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"filtre2"
						
						);
					}
					

          row4 = null;
    Operator_tFilterRow_2 ope_tFilterRow_2 = new Operator_tFilterRow_2("&&");    
        ope_tFilterRow_2.matches((filtre2.Date_inspection == null? false : filtre2.Date_inspection.length() == 10)
                       , " Date_inspection.length() == 10 failed");    
        ope_tFilterRow_2.matches((filtre2.SIRET == null? false : filtre2.SIRET.length() == 14)
                       , " SIRET.length() == 14 failed");    
        ope_tFilterRow_2.matches((filtre2.Code_postal == null? false : filtre2.Code_postal.length() == 5)
                       , " Code_postal.length() == 5 failed");    
        ope_tFilterRow_2.matches((filtre2.activite_de_l_etablissement == null? false : filtre2.activite_de_l_etablissement.length() > 0)
                       , " activite_de_l_etablissement.length() > 0 failed");    
        ope_tFilterRow_2.matches((filtre2.Adresse_etablissement == null? false : filtre2.Adresse_etablissement.length() > 0)
                       , " Adresse_etablissement.length() > 0 failed");    
        ope_tFilterRow_2.matches((filtre2.coordonnees_geographiques == null? false : filtre2.coordonnees_geographiques.length() > 0)
                       , " coordonnees_geographiques.length() > 0 failed");    
        ope_tFilterRow_2.matches((filtre2.Libelle_commune == null? false : filtre2.Libelle_commune.length() > 0)
                       , " Libelle_commune.length() > 0 failed");    
        ope_tFilterRow_2.matches((filtre2.Numero_inspection == null? false : filtre2.Numero_inspection.length() > 0)
                       , " Numero_inspection.length() > 0 failed");    
        ope_tFilterRow_2.matches((filtre2.nom_etablissement == null? false : filtre2.nom_etablissement.length() > 0)
                       , " nom_etablissement.length() > 0 failed");    
        ope_tFilterRow_2.matches((filtre2.activite_de_l_etablissement == null? false : filtre2.activite_de_l_etablissement.length() < 100)
                       , " activite_de_l_etablissement.length() < 100 failed");    
        ope_tFilterRow_2.matches((filtre2.Adresse_etablissement == null? false : filtre2.Adresse_etablissement.length() < 100)
                       , " Adresse_etablissement.length() < 100 failed");    
        ope_tFilterRow_2.matches((filtre2.coordonnees_geographiques == null? false : filtre2.coordonnees_geographiques.length() < 100)
                       , " coordonnees_geographiques.length() < 100 failed");    
        ope_tFilterRow_2.matches((filtre2.Libelle_commune == null? false : filtre2.Libelle_commune.length() < 100)
                       , " Libelle_commune.length() < 100 failed");    
        ope_tFilterRow_2.matches((filtre2.nom_etablissement == null? false : filtre2.nom_etablissement.length() < 100)
                       , " nom_etablissement.length() < 100 failed");    
        ope_tFilterRow_2.matches((filtre2.Date_inspection == null? false : filtre2.Date_inspection.length() < 20)
                       , " Date_inspection.length() < 20 failed");
    
    if (ope_tFilterRow_2.getMatchFlag()) {
              if(row4 == null){ 
                row4 = new row4Struct();
              }
               row4.coordonnees_geographiques = filtre2.coordonnees_geographiques;
               row4.activite_de_l_etablissement = filtre2.activite_de_l_etablissement;
               row4.Libelle_commune = filtre2.Libelle_commune;
               row4.Date_inspection = filtre2.Date_inspection;
               row4.Adresse_etablissement = filtre2.Adresse_etablissement;
               row4.nom_etablissement = filtre2.nom_etablissement;
               row4.Code_postal = filtre2.Code_postal;
               row4.SIRET = filtre2.SIRET;
               row4.Numero_inspection = filtre2.Numero_inspection;
               row4.evaluation_sanitaire = filtre2.evaluation_sanitaire;    
      nb_line_ok_tFilterRow_2++;
    } else {
      nb_line_reject_tFilterRow_2++;
    }

nb_line_tFilterRow_2++;

 


	tos_count_tFilterRow_2++;

/**
 * [tFilterRow_2 main ] stop
 */
	
	/**
	 * [tFilterRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFilterRow_2";

	

 



/**
 * [tFilterRow_2 process_data_begin ] stop
 */
// Start of branch "row4"
if(row4 != null) { 



	
	/**
	 * [tFilterRow_3 main ] start
	 */

	

	
	
	currentComponent="tFilterRow_3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row4"
						
						);
					}
					

          row5 = null;
    Operator_tFilterRow_3 ope_tFilterRow_3 = new Operator_tFilterRow_3("||");
            ope_tFilterRow_3.matches((row4.evaluation_sanitaire == null? false : row4.evaluation_sanitaire.compareTo("Satisfaisant") == 0)
                           , "evaluation_sanitaire.compareTo(\"Satisfaisant\") == 0 failed");
            ope_tFilterRow_3.matches((row4.evaluation_sanitaire == null? false : row4.evaluation_sanitaire.compareTo("Très satisfaisant") == 0)
                           , "evaluation_sanitaire.compareTo(\"Très satisfaisant\") == 0 failed");
            ope_tFilterRow_3.matches((row4.evaluation_sanitaire == null? false : row4.evaluation_sanitaire.compareTo("A améliorer") == 0)
                           , "evaluation_sanitaire.compareTo(\"A améliorer\") == 0 failed");
            ope_tFilterRow_3.matches((row4.evaluation_sanitaire == null? false : row4.evaluation_sanitaire.compareTo("A corriger de manière urgente") == 0)
                           , "evaluation_sanitaire.compareTo(\"A corriger de manière urgente\") == 0 failed");
    
    if (ope_tFilterRow_3.getMatchFlag()) {
              if(row5 == null){ 
                row5 = new row5Struct();
              }
               row5.coordonnees_geographiques = row4.coordonnees_geographiques;
               row5.activite_de_l_etablissement = row4.activite_de_l_etablissement;
               row5.Libelle_commune = row4.Libelle_commune;
               row5.Date_inspection = row4.Date_inspection;
               row5.Adresse_etablissement = row4.Adresse_etablissement;
               row5.nom_etablissement = row4.nom_etablissement;
               row5.Code_postal = row4.Code_postal;
               row5.SIRET = row4.SIRET;
               row5.Numero_inspection = row4.Numero_inspection;
               row5.evaluation_sanitaire = row4.evaluation_sanitaire;    
      nb_line_ok_tFilterRow_3++;
    } else {
      nb_line_reject_tFilterRow_3++;
    }

nb_line_tFilterRow_3++;

 


	tos_count_tFilterRow_3++;

/**
 * [tFilterRow_3 main ] stop
 */
	
	/**
	 * [tFilterRow_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFilterRow_3";

	

 



/**
 * [tFilterRow_3 process_data_begin ] stop
 */
// Start of branch "row5"
if(row5 != null) { 



	
	/**
	 * [tUniqRow_1 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row5"
						
						);
					}
					
row6 = null;			
if(row5.Numero_inspection == null){
	finder_tUniqRow_1.Numero_inspection = null;
}else{
	finder_tUniqRow_1.Numero_inspection = row5.Numero_inspection.toLowerCase();
}	
finder_tUniqRow_1.hashCodeDirty = true;
if (!keystUniqRow_1.contains(finder_tUniqRow_1)) {
		KeyStruct_tUniqRow_1 new_tUniqRow_1 = new KeyStruct_tUniqRow_1();

		
if(row5.Numero_inspection == null){
	new_tUniqRow_1.Numero_inspection = null;
}else{
	new_tUniqRow_1.Numero_inspection = row5.Numero_inspection.toLowerCase();
}
		
		keystUniqRow_1.add(new_tUniqRow_1);if(row6 == null){ 
	
	row6 = new row6Struct();
}row6.coordonnees_geographiques = row5.coordonnees_geographiques;			row6.activite_de_l_etablissement = row5.activite_de_l_etablissement;			row6.Libelle_commune = row5.Libelle_commune;			row6.Date_inspection = row5.Date_inspection;			row6.Adresse_etablissement = row5.Adresse_etablissement;			row6.nom_etablissement = row5.nom_etablissement;			row6.Code_postal = row5.Code_postal;			row6.SIRET = row5.SIRET;			row6.Numero_inspection = row5.Numero_inspection;			row6.evaluation_sanitaire = row5.evaluation_sanitaire;					
		nb_uniques_tUniqRow_1++;
	} else {
	  nb_duplicates_tUniqRow_1++;
	}

 


	tos_count_tUniqRow_1++;

/**
 * [tUniqRow_1 main ] stop
 */
	
	/**
	 * [tUniqRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";

	

 



/**
 * [tUniqRow_1 process_data_begin ] stop
 */
// Start of branch "row6"
if(row6 != null) { 



	
	/**
	 * [tMap_3 main ] start
	 */

	

	
	
	currentComponent="tMap_3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row6"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_3 = false;
		  boolean mainRowRejected_tMap_3 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
        // ###############################
        // # Output tables

localisation = null;
etablissement = null;
inspections = null;


// # Output table : 'localisation'
localisation_tmp.Adresse_etablissement = row6.Adresse_etablissement  ;
localisation_tmp.coordonnees_geographiques = row6.coordonnees_geographiques  ;
localisation_tmp.Libelle_commune = row6.Libelle_commune  ;
localisation_tmp.Code_postal = Integer.parseInt(row6.Code_postal)  ;
localisation = localisation_tmp;

// # Output table : 'etablissement'
etablissement_tmp.SIRET = Long.parseLong(row6.SIRET)  ;
etablissement_tmp.activite_de_l_etablissement = row6.activite_de_l_etablissement  ;
etablissement_tmp.nom_etablissement = row6.nom_etablissement  ;
etablissement = etablissement_tmp;

// # Output table : 'inspections'
inspections_tmp.Numero_inspection = row6.Numero_inspection  ;
inspections_tmp.evaluation_sanitaire = row6.evaluation_sanitaire  ;
inspections_tmp.Date_inspection = TalendDate.parseDate("yyyy-MM-dd",row6.Date_inspection ) ;
inspections = inspections_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_3 = false;










 


	tos_count_tMap_3++;

/**
 * [tMap_3 main ] stop
 */
	
	/**
	 * [tMap_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 process_data_begin ] stop
 */
// Start of branch "localisation"
if(localisation != null) { 



	
	/**
	 * [tUniqRow_2 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"localisation"
						
						);
					}
					
row9 = null;			
if(localisation.Adresse_etablissement == null){
	finder_tUniqRow_2.Adresse_etablissement = null;
}else{
	finder_tUniqRow_2.Adresse_etablissement = localisation.Adresse_etablissement.toLowerCase();
}	
finder_tUniqRow_2.hashCodeDirty = true;
if (!keystUniqRow_2.contains(finder_tUniqRow_2)) {
		KeyStruct_tUniqRow_2 new_tUniqRow_2 = new KeyStruct_tUniqRow_2();

		
if(localisation.Adresse_etablissement == null){
	new_tUniqRow_2.Adresse_etablissement = null;
}else{
	new_tUniqRow_2.Adresse_etablissement = localisation.Adresse_etablissement.toLowerCase();
}
		
		keystUniqRow_2.add(new_tUniqRow_2);if(row9 == null){ 
	
	row9 = new row9Struct();
}row9.Adresse_etablissement = localisation.Adresse_etablissement;			row9.coordonnees_geographiques = localisation.coordonnees_geographiques;			row9.Libelle_commune = localisation.Libelle_commune;			row9.Code_postal = localisation.Code_postal;					
		nb_uniques_tUniqRow_2++;
	} else {
	  nb_duplicates_tUniqRow_2++;
	}

 


	tos_count_tUniqRow_2++;

/**
 * [tUniqRow_2 main ] stop
 */
	
	/**
	 * [tUniqRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";

	

 



/**
 * [tUniqRow_2 process_data_begin ] stop
 */
// Start of branch "row9"
if(row9 != null) { 



	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row9"
						
						);
					}
					
	



        whetherReject_tDBOutput_1 = false;
                    if(row9.Adresse_etablissement == null) {
pstmt_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(1, row9.Adresse_etablissement);
}

                    if(row9.coordonnees_geographiques == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, row9.coordonnees_geographiques);
}

                    if(row9.Libelle_commune == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, row9.Libelle_commune);
}

                    if(row9.Code_postal == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(4, row9.Code_postal);
}


                       pstmt_tDBOutput_1.addBatch();
                       batchSizeCounter_tDBOutput_1++;
                       nb_line_tDBOutput_1++;
                if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                    int[] status_tDBOutput_1 = null;
                    int countSum_tDBOutput_1 = 0;
                    try {
                        batchSizeCounter_tDBOutput_1 = 0;
                        status_tDBOutput_1 = pstmt_tDBOutput_1.executeBatch();
                        for(int countEach_tDBOutput_1: status_tDBOutput_1) {
                            countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
                        }
                    }catch (java.sql.BatchUpdateException e){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e.getMessage());
                        for(int countEach_tDBOutput_1: e.getUpdateCounts()) {
                            countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
                        }
                        System.err.println(e.getMessage());
                    }
                    try {
                        tmp_batchUpdateCount_tDBOutput_1 = pstmt_tDBOutput_1.getUpdateCount();
                    }catch (java.sql.SQLException e){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e.getMessage());
                        System.err.println(e.getMessage());
                    }
                    tmp_batchUpdateCount_tDBOutput_1 = tmp_batchUpdateCount_tDBOutput_1 > countSum_tDBOutput_1 ? tmp_batchUpdateCount_tDBOutput_1 : countSum_tDBOutput_1;
                    rowsToCommitCount_tDBOutput_1 += tmp_batchUpdateCount_tDBOutput_1;
                        insertedCount_tDBOutput_1 += tmp_batchUpdateCount_tDBOutput_1;
               }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */

} // End of branch "row9"




	
	/**
	 * [tUniqRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";

	

 



/**
 * [tUniqRow_2 process_data_end ] stop
 */

} // End of branch "localisation"




// Start of branch "etablissement"
if(etablissement != null) { 



	
	/**
	 * [tUniqRow_3 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"etablissement"
						
						);
					}
					
row8 = null;			
finder_tUniqRow_3.SIRET = etablissement.SIRET;	
finder_tUniqRow_3.hashCodeDirty = true;
if (!keystUniqRow_3.contains(finder_tUniqRow_3)) {
		KeyStruct_tUniqRow_3 new_tUniqRow_3 = new KeyStruct_tUniqRow_3();

		
new_tUniqRow_3.SIRET = etablissement.SIRET;
		
		keystUniqRow_3.add(new_tUniqRow_3);if(row8 == null){ 
	
	row8 = new row8Struct();
}row8.SIRET = etablissement.SIRET;			row8.activite_de_l_etablissement = etablissement.activite_de_l_etablissement;			row8.nom_etablissement = etablissement.nom_etablissement;					
		nb_uniques_tUniqRow_3++;
	} else {
	  nb_duplicates_tUniqRow_3++;
	}

 


	tos_count_tUniqRow_3++;

/**
 * [tUniqRow_3 main ] stop
 */
	
	/**
	 * [tUniqRow_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_3";

	

 



/**
 * [tUniqRow_3 process_data_begin ] stop
 */
// Start of branch "row8"
if(row8 != null) { 



	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row8"
						
						);
					}
					
	



        whetherReject_tDBOutput_2 = false;
                    if(row8.SIRET == null) {
pstmt_tDBOutput_2.setNull(1, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setLong(1, row8.SIRET);
}

                    if(row8.activite_de_l_etablissement == null) {
pstmt_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(2, row8.activite_de_l_etablissement);
}

                    if(row8.nom_etablissement == null) {
pstmt_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(3, row8.nom_etablissement);
}


                       pstmt_tDBOutput_2.addBatch();
                       batchSizeCounter_tDBOutput_2++;
                       nb_line_tDBOutput_2++;
                if ((batchSize_tDBOutput_2 > 0) && (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {
                    int[] status_tDBOutput_2 = null;
                    int countSum_tDBOutput_2 = 0;
                    try {
                        batchSizeCounter_tDBOutput_2 = 0;
                        status_tDBOutput_2 = pstmt_tDBOutput_2.executeBatch();
                        for(int countEach_tDBOutput_2: status_tDBOutput_2) {
                            countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
                        }
                    }catch (java.sql.BatchUpdateException e){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e.getMessage());
                        for(int countEach_tDBOutput_2: e.getUpdateCounts()) {
                            countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
                        }
                        System.err.println(e.getMessage());
                    }
                    try {
                        tmp_batchUpdateCount_tDBOutput_2 = pstmt_tDBOutput_2.getUpdateCount();
                    }catch (java.sql.SQLException e){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e.getMessage());
                        System.err.println(e.getMessage());
                    }
                    tmp_batchUpdateCount_tDBOutput_2 = tmp_batchUpdateCount_tDBOutput_2 > countSum_tDBOutput_2 ? tmp_batchUpdateCount_tDBOutput_2 : countSum_tDBOutput_2;
                    rowsToCommitCount_tDBOutput_2 += tmp_batchUpdateCount_tDBOutput_2;
                        insertedCount_tDBOutput_2 += tmp_batchUpdateCount_tDBOutput_2;
               }

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */

} // End of branch "row8"




	
	/**
	 * [tUniqRow_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_3";

	

 



/**
 * [tUniqRow_3 process_data_end ] stop
 */

} // End of branch "etablissement"




// Start of branch "inspections"
if(inspections != null) { 



	
	/**
	 * [tUniqRow_4 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_4";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"inspections"
						
						);
					}
					
row7 = null;			
if(inspections.Numero_inspection == null){
	finder_tUniqRow_4.Numero_inspection = null;
}else{
	finder_tUniqRow_4.Numero_inspection = inspections.Numero_inspection.toLowerCase();
}	
finder_tUniqRow_4.hashCodeDirty = true;
if (!keystUniqRow_4.contains(finder_tUniqRow_4)) {
		KeyStruct_tUniqRow_4 new_tUniqRow_4 = new KeyStruct_tUniqRow_4();

		
if(inspections.Numero_inspection == null){
	new_tUniqRow_4.Numero_inspection = null;
}else{
	new_tUniqRow_4.Numero_inspection = inspections.Numero_inspection.toLowerCase();
}
		
		keystUniqRow_4.add(new_tUniqRow_4);if(row7 == null){ 
	
	row7 = new row7Struct();
}row7.Numero_inspection = inspections.Numero_inspection;			row7.evaluation_sanitaire = inspections.evaluation_sanitaire;			row7.Date_inspection = inspections.Date_inspection;					
		nb_uniques_tUniqRow_4++;
	} else {
	  nb_duplicates_tUniqRow_4++;
	}

 


	tos_count_tUniqRow_4++;

/**
 * [tUniqRow_4 main ] stop
 */
	
	/**
	 * [tUniqRow_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_4";

	

 



/**
 * [tUniqRow_4 process_data_begin ] stop
 */
// Start of branch "row7"
if(row7 != null) { 



	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row7"
						
						);
					}
					
	



        whetherReject_tDBOutput_3 = false;
                    if(row7.Numero_inspection == null) {
pstmt_tDBOutput_3.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(1, row7.Numero_inspection);
}

                    if(row7.evaluation_sanitaire == null) {
pstmt_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(2, row7.evaluation_sanitaire);
}

                    if(row7.Date_inspection != null) {
pstmt_tDBOutput_3.setTimestamp(3, new java.sql.Timestamp(row7.Date_inspection.getTime()));
} else {
pstmt_tDBOutput_3.setNull(3, java.sql.Types.TIMESTAMP);
}


                       pstmt_tDBOutput_3.addBatch();
                       batchSizeCounter_tDBOutput_3++;
                       nb_line_tDBOutput_3++;
                if ((batchSize_tDBOutput_3 > 0) && (batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3)) {
                    int[] status_tDBOutput_3 = null;
                    int countSum_tDBOutput_3 = 0;
                    try {
                        batchSizeCounter_tDBOutput_3 = 0;
                        status_tDBOutput_3 = pstmt_tDBOutput_3.executeBatch();
                        for(int countEach_tDBOutput_3: status_tDBOutput_3) {
                            countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
                        }
                    }catch (java.sql.BatchUpdateException e){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e.getMessage());
                        for(int countEach_tDBOutput_3: e.getUpdateCounts()) {
                            countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
                        }
                        System.err.println(e.getMessage());
                    }
                    try {
                        tmp_batchUpdateCount_tDBOutput_3 = pstmt_tDBOutput_3.getUpdateCount();
                    }catch (java.sql.SQLException e){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e.getMessage());
                        System.err.println(e.getMessage());
                    }
                    tmp_batchUpdateCount_tDBOutput_3 = tmp_batchUpdateCount_tDBOutput_3 > countSum_tDBOutput_3 ? tmp_batchUpdateCount_tDBOutput_3 : countSum_tDBOutput_3;
                    rowsToCommitCount_tDBOutput_3 += tmp_batchUpdateCount_tDBOutput_3;
                        insertedCount_tDBOutput_3 += tmp_batchUpdateCount_tDBOutput_3;
               }

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */

} // End of branch "row7"




	
	/**
	 * [tUniqRow_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_4";

	

 



/**
 * [tUniqRow_4 process_data_end ] stop
 */

} // End of branch "inspections"




	
	/**
	 * [tMap_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 process_data_end ] stop
 */

} // End of branch "row6"




	
	/**
	 * [tUniqRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";

	

 



/**
 * [tUniqRow_1 process_data_end ] stop
 */

} // End of branch "row5"




	
	/**
	 * [tFilterRow_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tFilterRow_3";

	

 



/**
 * [tFilterRow_3 process_data_end ] stop
 */

} // End of branch "row4"




	
	/**
	 * [tFilterRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFilterRow_2";

	

 



/**
 * [tFilterRow_2 process_data_end ] stop
 */

} // End of branch "filtre2"




	
	/**
	 * [tMap_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 process_data_end ] stop
 */

} // End of branch "premier_filtre"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_end ] stop
 */

} // End of branch "row1"




// Start of branch "row3"
if(row3 != null) { 



	
	/**
	 * [tLogRow_2 main ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row3"
						
						);
					}
					
///////////////////////		
						

				
				String[] row_tLogRow_2 = new String[14];
   				
	    		if(row3.APP_Libelle_etablissement != null) { //              
                 row_tLogRow_2[0]=    						    
				                String.valueOf(row3.APP_Libelle_etablissement)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.SIRET != null) { //              
                 row_tLogRow_2[1]=    						    
				                String.valueOf(row3.SIRET)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.Adresse_2_UA != null) { //              
                 row_tLogRow_2[2]=    						    
				                String.valueOf(row3.Adresse_2_UA)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.Code_postal != null) { //              
                 row_tLogRow_2[3]=    						    
				                String.valueOf(row3.Code_postal)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.Libelle_commune != null) { //              
                 row_tLogRow_2[4]=    						    
				                String.valueOf(row3.Libelle_commune)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.Numero_inspection != null) { //              
                 row_tLogRow_2[5]=    						    
				                String.valueOf(row3.Numero_inspection)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.Date_inspection != null) { //              
                 row_tLogRow_2[6]=    						    
				                String.valueOf(row3.Date_inspection)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.APP_Libelle_activite_etablissement != null) { //              
                 row_tLogRow_2[7]=    						    
				                String.valueOf(row3.APP_Libelle_activite_etablissement)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.Synthese_eval_sanit != null) { //              
                 row_tLogRow_2[8]=    						    
				                String.valueOf(row3.Synthese_eval_sanit)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.Agrement != null) { //              
                 row_tLogRow_2[9]=    						    
				                String.valueOf(row3.Agrement)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.geores != null) { //              
                 row_tLogRow_2[10]=    						    
				                String.valueOf(row3.geores)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.filtre != null) { //              
                 row_tLogRow_2[11]=    						    
				                String.valueOf(row3.filtre)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.ods_type_activite != null) { //              
                 row_tLogRow_2[12]=    						    
				                String.valueOf(row3.ods_type_activite)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.errorMessage != null) { //              
                 row_tLogRow_2[13]=    						    
				                String.valueOf(row3.errorMessage)			
					          ;	
							
	    		} //			
    			 

				util_tLogRow_2.addRow(row_tLogRow_2);	
				nb_line_tLogRow_2++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_tLogRow_2++;

/**
 * [tLogRow_2 main ] stop
 */
	
	/**
	 * [tLogRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	

 



/**
 * [tLogRow_2 process_data_begin ] stop
 */
	
	/**
	 * [tLogRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	

 



/**
 * [tLogRow_2 process_data_end ] stop
 */

} // End of branch "row3"




	
	/**
	 * [tFilterRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFilterRow_1";

	

 



/**
 * [tFilterRow_1 process_data_end ] stop
 */

} // End of branch "row2"




	
	/**
	 * [tFileInputDelimited_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	



            }
            }finally{
                if(!((Object)(context.context_alimconfiance_File) instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_1!=null){
                		fid_tFileInputDelimited_1.close();
                	}
                }
                if(fid_tFileInputDelimited_1!=null){
                	globalMap.put("tFileInputDelimited_1_NB_LINE", fid_tFileInputDelimited_1.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_1", true);
end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());




/**
 * [tFileInputDelimited_1 end ] stop
 */

	
	/**
	 * [tFilterRow_1 end ] start
	 */

	

	
	
	currentComponent="tFilterRow_1";

	
    globalMap.put("tFilterRow_1_NB_LINE", nb_line_tFilterRow_1);
    globalMap.put("tFilterRow_1_NB_LINE_OK", nb_line_ok_tFilterRow_1);
    globalMap.put("tFilterRow_1_NB_LINE_REJECT", nb_line_reject_tFilterRow_1);
    

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row2");
			  	}
			  	
 

ok_Hash.put("tFilterRow_1", true);
end_Hash.put("tFilterRow_1", System.currentTimeMillis());




/**
 * [tFilterRow_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row1");
			  	}
			  	
 

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tMap_2 end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"premier_filtre");
			  	}
			  	
 

ok_Hash.put("tMap_2", true);
end_Hash.put("tMap_2", System.currentTimeMillis());




/**
 * [tMap_2 end ] stop
 */

	
	/**
	 * [tFilterRow_2 end ] start
	 */

	

	
	
	currentComponent="tFilterRow_2";

	
    globalMap.put("tFilterRow_2_NB_LINE", nb_line_tFilterRow_2);
    globalMap.put("tFilterRow_2_NB_LINE_OK", nb_line_ok_tFilterRow_2);
    globalMap.put("tFilterRow_2_NB_LINE_REJECT", nb_line_reject_tFilterRow_2);
    

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"filtre2");
			  	}
			  	
 

ok_Hash.put("tFilterRow_2", true);
end_Hash.put("tFilterRow_2", System.currentTimeMillis());




/**
 * [tFilterRow_2 end ] stop
 */

	
	/**
	 * [tFilterRow_3 end ] start
	 */

	

	
	
	currentComponent="tFilterRow_3";

	
    globalMap.put("tFilterRow_3_NB_LINE", nb_line_tFilterRow_3);
    globalMap.put("tFilterRow_3_NB_LINE_OK", nb_line_ok_tFilterRow_3);
    globalMap.put("tFilterRow_3_NB_LINE_REJECT", nb_line_reject_tFilterRow_3);
    

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row4");
			  	}
			  	
 

ok_Hash.put("tFilterRow_3", true);
end_Hash.put("tFilterRow_3", System.currentTimeMillis());




/**
 * [tFilterRow_3 end ] stop
 */

	
	/**
	 * [tUniqRow_1 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";

	

globalMap.put("tUniqRow_1_NB_UNIQUES",nb_uniques_tUniqRow_1);
globalMap.put("tUniqRow_1_NB_DUPLICATES",nb_duplicates_tUniqRow_1);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row5");
			  	}
			  	
 

ok_Hash.put("tUniqRow_1", true);
end_Hash.put("tUniqRow_1", System.currentTimeMillis());




/**
 * [tUniqRow_1 end ] stop
 */

	
	/**
	 * [tMap_3 end ] start
	 */

	

	
	
	currentComponent="tMap_3";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row6");
			  	}
			  	
 

ok_Hash.put("tMap_3", true);
end_Hash.put("tMap_3", System.currentTimeMillis());




/**
 * [tMap_3 end ] stop
 */

	
	/**
	 * [tUniqRow_2 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";

	

globalMap.put("tUniqRow_2_NB_UNIQUES",nb_uniques_tUniqRow_2);
globalMap.put("tUniqRow_2_NB_DUPLICATES",nb_duplicates_tUniqRow_2);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"localisation");
			  	}
			  	
 

ok_Hash.put("tUniqRow_2", true);
end_Hash.put("tUniqRow_2", System.currentTimeMillis());




/**
 * [tUniqRow_2 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	




                    int[] status_tDBOutput_1 = null;
                    int countSum_tDBOutput_1 = 0;
                    try {
                        if(pstmt_tDBOutput_1!=null && batchSizeCounter_tDBOutput_1 > 0 ){
                            status_tDBOutput_1 = pstmt_tDBOutput_1.executeBatch();
                            for(int countEach_tDBOutput_1: status_tDBOutput_1) {
                                countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
                            }
                        }
                    }catch (java.sql.BatchUpdateException e){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e.getMessage());
                        for(int countEach_tDBOutput_1: e.getUpdateCounts()) {
                            countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
                        }
                        System.err.println(e.getMessage());
                    }
                    if(pstmt_tDBOutput_1!=null && batchSizeCounter_tDBOutput_1 > 0 ){
                        try {
                            tmp_batchUpdateCount_tDBOutput_1 = pstmt_tDBOutput_1.getUpdateCount();
                        }catch (java.sql.SQLException e){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e.getMessage());

                        }
                        tmp_batchUpdateCount_tDBOutput_1 = tmp_batchUpdateCount_tDBOutput_1 > countSum_tDBOutput_1 ? tmp_batchUpdateCount_tDBOutput_1 : countSum_tDBOutput_1;
                        rowsToCommitCount_tDBOutput_1 += tmp_batchUpdateCount_tDBOutput_1;
                            insertedCount_tDBOutput_1 += tmp_batchUpdateCount_tDBOutput_1;
                    }
        if(pstmt_tDBOutput_1 != null) {
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);

	int rejectedCount_tDBOutput_1 = 0;
	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row9");
			  	}
			  	
 

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */







	
	/**
	 * [tUniqRow_3 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_3";

	

globalMap.put("tUniqRow_3_NB_UNIQUES",nb_uniques_tUniqRow_3);
globalMap.put("tUniqRow_3_NB_DUPLICATES",nb_duplicates_tUniqRow_3);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"etablissement");
			  	}
			  	
 

ok_Hash.put("tUniqRow_3", true);
end_Hash.put("tUniqRow_3", System.currentTimeMillis());




/**
 * [tUniqRow_3 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	




                    int[] status_tDBOutput_2 = null;
                    int countSum_tDBOutput_2 = 0;
                    try {
                        if(pstmt_tDBOutput_2!=null && batchSizeCounter_tDBOutput_2 > 0 ){
                            status_tDBOutput_2 = pstmt_tDBOutput_2.executeBatch();
                            for(int countEach_tDBOutput_2: status_tDBOutput_2) {
                                countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
                            }
                        }
                    }catch (java.sql.BatchUpdateException e){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e.getMessage());
                        for(int countEach_tDBOutput_2: e.getUpdateCounts()) {
                            countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
                        }
                        System.err.println(e.getMessage());
                    }
                    if(pstmt_tDBOutput_2!=null && batchSizeCounter_tDBOutput_2 > 0 ){
                        try {
                            tmp_batchUpdateCount_tDBOutput_2 = pstmt_tDBOutput_2.getUpdateCount();
                        }catch (java.sql.SQLException e){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e.getMessage());

                        }
                        tmp_batchUpdateCount_tDBOutput_2 = tmp_batchUpdateCount_tDBOutput_2 > countSum_tDBOutput_2 ? tmp_batchUpdateCount_tDBOutput_2 : countSum_tDBOutput_2;
                        rowsToCommitCount_tDBOutput_2 += tmp_batchUpdateCount_tDBOutput_2;
                            insertedCount_tDBOutput_2 += tmp_batchUpdateCount_tDBOutput_2;
                    }
        if(pstmt_tDBOutput_2 != null) {
            pstmt_tDBOutput_2.close();
            resourceMap.remove("pstmt_tDBOutput_2");
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);

	int rejectedCount_tDBOutput_2 = 0;
	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row8");
			  	}
			  	
 

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */







	
	/**
	 * [tUniqRow_4 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_4";

	

globalMap.put("tUniqRow_4_NB_UNIQUES",nb_uniques_tUniqRow_4);
globalMap.put("tUniqRow_4_NB_DUPLICATES",nb_duplicates_tUniqRow_4);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"inspections");
			  	}
			  	
 

ok_Hash.put("tUniqRow_4", true);
end_Hash.put("tUniqRow_4", System.currentTimeMillis());




/**
 * [tUniqRow_4 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	




                    int[] status_tDBOutput_3 = null;
                    int countSum_tDBOutput_3 = 0;
                    try {
                        if(pstmt_tDBOutput_3!=null && batchSizeCounter_tDBOutput_3 > 0 ){
                            status_tDBOutput_3 = pstmt_tDBOutput_3.executeBatch();
                            for(int countEach_tDBOutput_3: status_tDBOutput_3) {
                                countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
                            }
                        }
                    }catch (java.sql.BatchUpdateException e){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e.getMessage());
                        for(int countEach_tDBOutput_3: e.getUpdateCounts()) {
                            countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
                        }
                        System.err.println(e.getMessage());
                    }
                    if(pstmt_tDBOutput_3!=null && batchSizeCounter_tDBOutput_3 > 0 ){
                        try {
                            tmp_batchUpdateCount_tDBOutput_3 = pstmt_tDBOutput_3.getUpdateCount();
                        }catch (java.sql.SQLException e){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e.getMessage());

                        }
                        tmp_batchUpdateCount_tDBOutput_3 = tmp_batchUpdateCount_tDBOutput_3 > countSum_tDBOutput_3 ? tmp_batchUpdateCount_tDBOutput_3 : countSum_tDBOutput_3;
                        rowsToCommitCount_tDBOutput_3 += tmp_batchUpdateCount_tDBOutput_3;
                            insertedCount_tDBOutput_3 += tmp_batchUpdateCount_tDBOutput_3;
                    }
        if(pstmt_tDBOutput_3 != null) {
            pstmt_tDBOutput_3.close();
            resourceMap.remove("pstmt_tDBOutput_3");
        }
    resourceMap.put("statementClosed_tDBOutput_3", true);

	int rejectedCount_tDBOutput_3 = 0;
	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
        globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row7");
			  	}
			  	
 

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());




/**
 * [tDBOutput_3 end ] stop
 */

























	
	/**
	 * [tLogRow_2 end ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	


//////

                    
                    java.io.PrintStream consoleOut_tLogRow_2 = null;
                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_2 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_2 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_2);
                    }
                    
                    consoleOut_tLogRow_2.println(util_tLogRow_2.format().toString());
                    consoleOut_tLogRow_2.flush();
//////
globalMap.put("tLogRow_2_NB_LINE",nb_line_tLogRow_2);

///////////////////////    			

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row3");
			  	}
			  	
 

ok_Hash.put("tLogRow_2", true);
end_Hash.put("tLogRow_2", System.currentTimeMillis());




/**
 * [tLogRow_2 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tDBCommit_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 finally ] stop
 */

	
	/**
	 * [tFilterRow_1 finally ] start
	 */

	

	
	
	currentComponent="tFilterRow_1";

	

 



/**
 * [tFilterRow_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tMap_2 finally ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 finally ] stop
 */

	
	/**
	 * [tFilterRow_2 finally ] start
	 */

	

	
	
	currentComponent="tFilterRow_2";

	

 



/**
 * [tFilterRow_2 finally ] stop
 */

	
	/**
	 * [tFilterRow_3 finally ] start
	 */

	

	
	
	currentComponent="tFilterRow_3";

	

 



/**
 * [tFilterRow_3 finally ] stop
 */

	
	/**
	 * [tUniqRow_1 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";

	

 



/**
 * [tUniqRow_1 finally ] stop
 */

	
	/**
	 * [tMap_3 finally ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 finally ] stop
 */

	
	/**
	 * [tUniqRow_2 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";

	

 



/**
 * [tUniqRow_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */







	
	/**
	 * [tUniqRow_3 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_3";

	

 



/**
 * [tUniqRow_3 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	



    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */







	
	/**
	 * [tUniqRow_4 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_4";

	

 



/**
 * [tUniqRow_4 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	



    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */

























	
	/**
	 * [tLogRow_2 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	

 



/**
 * [tLogRow_2 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBCommit_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBCommit_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBCommit_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBCommit_1", false);
		start_Hash.put("tDBCommit_1", System.currentTimeMillis());
		
	
	currentComponent="tDBCommit_1";

	
		int tos_count_tDBCommit_1 = 0;
		

 



/**
 * [tDBCommit_1 begin ] stop
 */
	
	/**
	 * [tDBCommit_1 main ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";

	

	java.sql.Connection conn_tDBCommit_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
	if(conn_tDBCommit_1 != null && !conn_tDBCommit_1.isClosed())
	{
	
		try{
	
			
			conn_tDBCommit_1.commit();
			
	
		}finally{
			
			conn_tDBCommit_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_tDBConnection_1"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	    }
	
	}

 


	tos_count_tDBCommit_1++;

/**
 * [tDBCommit_1 main ] stop
 */
	
	/**
	 * [tDBCommit_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";

	

 



/**
 * [tDBCommit_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBCommit_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";

	

 



/**
 * [tDBCommit_1 process_data_end ] stop
 */
	
	/**
	 * [tDBCommit_1 end ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";

	

 

ok_Hash.put("tDBCommit_1", true);
end_Hash.put("tDBCommit_1", System.currentTimeMillis());




/**
 * [tDBCommit_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBCommit_1 finally ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";

	

 



/**
 * [tDBCommit_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBCommit_1_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final projet_data_3 projet_data_3Class = new projet_data_3();

        int exitCode = projet_data_3Class.runJobInTOS(args);

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

    	
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        if (inOSGi) {
            java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

            if (jobProperties != null && jobProperties.get("context") != null) {
                contextStr = (String)jobProperties.get("context");
            }
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = projet_data_3.class.getClassLoader().getResourceAsStream("projet_data/projet_data_3_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = projet_data_3.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("connexion_projet_File", "id_File");
                        if(context.getStringValue("connexion_projet_File") == null) {
                            context.connexion_projet_File = null;
                        } else {
                            context.connexion_projet_File=(String) context.getProperty("connexion_projet_File");
                        }
                        context.setContextType("context_alimconfiance_Encoding", "id_String");
                        if(context.getStringValue("context_alimconfiance_Encoding") == null) {
                            context.context_alimconfiance_Encoding = null;
                        } else {
                            context.context_alimconfiance_Encoding=(String) context.getProperty("context_alimconfiance_Encoding");
                        }
                        context.setContextType("context_alimconfiance_FieldSeparator", "id_String");
                        if(context.getStringValue("context_alimconfiance_FieldSeparator") == null) {
                            context.context_alimconfiance_FieldSeparator = null;
                        } else {
                            context.context_alimconfiance_FieldSeparator=(String) context.getProperty("context_alimconfiance_FieldSeparator");
                        }
                        context.setContextType("context_alimconfiance_File", "id_File");
                        if(context.getStringValue("context_alimconfiance_File") == null) {
                            context.context_alimconfiance_File = null;
                        } else {
                            context.context_alimconfiance_File=(String) context.getProperty("context_alimconfiance_File");
                        }
                        context.setContextType("context_alimconfiance_Header", "id_Integer");
                        if(context.getStringValue("context_alimconfiance_Header") == null) {
                            context.context_alimconfiance_Header = null;
                        } else {
                            try{
                                context.context_alimconfiance_Header=routines.system.ParserUtils.parseTo_Integer (context.getProperty("context_alimconfiance_Header"));
                            } catch(NumberFormatException e){
                                System.err.println(String.format("Null value will be used for context parameter %s: %s", "context_alimconfiance_Header", e.getMessage()));
                                context.context_alimconfiance_Header=null;
                            }
                        }
                        context.setContextType("context_alimconfiance_RowSeparator", "id_String");
                        if(context.getStringValue("context_alimconfiance_RowSeparator") == null) {
                            context.context_alimconfiance_RowSeparator = null;
                        } else {
                            context.context_alimconfiance_RowSeparator=(String) context.getProperty("context_alimconfiance_RowSeparator");
                        }
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("connexion_projet_File")) {
                context.connexion_projet_File = (String) parentContextMap.get("connexion_projet_File");
            }if (parentContextMap.containsKey("context_alimconfiance_Encoding")) {
                context.context_alimconfiance_Encoding = (String) parentContextMap.get("context_alimconfiance_Encoding");
            }if (parentContextMap.containsKey("context_alimconfiance_FieldSeparator")) {
                context.context_alimconfiance_FieldSeparator = (String) parentContextMap.get("context_alimconfiance_FieldSeparator");
            }if (parentContextMap.containsKey("context_alimconfiance_File")) {
                context.context_alimconfiance_File = (String) parentContextMap.get("context_alimconfiance_File");
            }if (parentContextMap.containsKey("context_alimconfiance_Header")) {
                context.context_alimconfiance_Header = (Integer) parentContextMap.get("context_alimconfiance_Header");
            }if (parentContextMap.containsKey("context_alimconfiance_RowSeparator")) {
                context.context_alimconfiance_RowSeparator = (String) parentContextMap.get("context_alimconfiance_RowSeparator");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob





this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBConnection_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBConnection_1) {
globalMap.put("tDBConnection_1_SUBPROCESS_STATE", -1);

e_tDBConnection_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : projet_data_3");
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     278412 characters generated by Talend Open Studio for Data Integration 
 *     on the 12 novembre 2023, 15:53:52 CET
 ************************************************************************************************/